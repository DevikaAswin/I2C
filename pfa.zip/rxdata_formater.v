//=============================================================================
// rxdata_formater.v
//
// ARINC 818 Receive Data Formatter / Comma Aligner — Stub Module
//
// In a full implementation, this module performs byte-level alignment
// of received 8b/10b decoded data so that K28.5 comma characters
// appear at consistent byte positions within the 32-bit word.
//
// This stub passes data through unmodified. Replace with full
// implementation when RX path alignment is needed.
//=============================================================================

`timescale 1ns / 1ps

module rxdata_formater (
  input             clk,
  input             rst_n,
  input      [31:0] advb_rxdata,
  input      [3:0]  advb_rxcharisk,
  output reg [31:0] aligned_advb_rxdata,
  output reg [3:0]  aligned_advb_rxcharisk
);

//=========================================================================
// Pass-through (stub implementation)
//
// In production, this module would:
//   1. Detect K28.5 comma character position within the 4-byte word
//   2. Barrel-shift the data so commas always land on byte 0
//   3. Handle split K-characters that span word boundaries
//=========================================================================
always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin
    aligned_advb_rxdata    <= 32'd0;
    aligned_advb_rxcharisk <= 4'd0;
  end
  else begin
    aligned_advb_rxdata    <= advb_rxdata;
    aligned_advb_rxcharisk <= advb_rxcharisk;
  end
end

endmodule
