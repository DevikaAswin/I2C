//=============================================================================
// arinc818_core.v  —  MULTI-STREAM ARINC 818 Core
//
// Multi-stream TX + RX Path Integration (1920×1080 @ 60Hz for SAM G3 Viewer)
//
// NEW: Supports NUM_STREAMS independent video inputs, each with its own
// async FIFO for clock-domain crossing. All streams are multiplexed onto
// a single ADVB output link by the multi-stream advbtx module.
//
// Architecture:
//
//  Stream 0 Data ──► TX Async FIFO 0 ──┐
//  Stream 1 Data ──► TX Async FIFO 1 ──┤──► ADVB TX (multi-stream) ──► GTH TX
//  Stream N Data ──► TX Async FIFO N ──┘
//
//  GTH RX ──► RX Formatter ──► ADVB RX ──► RX Async FIFO ──► RX Data Out
//
//=============================================================================

`timescale 1ns / 1ps

module arinc818_core #(
  //=========================================================================
  // NEW PARAMETER: Number of video streams to multiplex.
  // This propagates to advbtx and controls how many TX FIFOs are instantiated.
  //=========================================================================
  parameter NUM_STREAMS = 2
)(
  input  wire        clk,                           // System clock (image gen domain)
  input  wire        tx_userclk2,                   // TX user clock from transceiver
  input  wire        rx_userclk2,                   // RX user clock from transceiver
  input  wire        rst_n,                         // Active-low reset

  //=========================================================================
  // CHANGED: TX FIFO interface is now NUM_STREAMS-wide.
  // Each stream has its own write-data, write-enable, and full flag.
  //
  // txfifo_wfull [NUM_STREAMS-1:0]    — one full flag per stream
  // txfifo_wdata [NUM_STREAMS*32-1:0] — concatenated 32-bit write data
  // txfifo_wren  [NUM_STREAMS-1:0]    — one write-enable per stream
  //=========================================================================
  output wire [NUM_STREAMS-1:0]    txfifo_wfull,    // Per-stream TX FIFO full flags
  input  wire [NUM_STREAMS*32-1:0] txfifo_wdata,    // Per-stream TX FIFO write data
  input  wire [NUM_STREAMS-1:0]    txfifo_wren,     // Per-stream TX FIFO write enables

  //=========================================================================
  // ADVB link interface (unchanged — single physical link)
  //=========================================================================
  output wire [31:0] advb_txdata,                    // TX data to transceiver
  output wire [3:0]  advb_txcharisk,                 // TX K-char flags to transceiver
  input  wire [31:0] advb_rxdata,                    // RX data from transceiver
  input  wire [3:0]  advb_rxcharisk,                 // RX K-char flags from transceiver

  //=========================================================================
  // RX FIFO interface (unchanged — single output stream)
  //=========================================================================
  output wire        rxfifo_rempty,                  // RX FIFO empty flag
  input  wire        rxfifo_rden,                    // RX FIFO read enable
  output wire [31:0] rxfifo_rdata                    // RX FIFO read data
);

//=========================================================================
// Internal Wires
//=========================================================================

// Per-stream FIFO read-side signals (from TX FIFOs to advbtx)
wire [NUM_STREAMS-1:0]    txfifo_rden;     // advbtx asserts these per-stream
wire [NUM_STREAMS*32-1:0] txfifo_rdata;    // Concatenated read data from all FIFOs
wire [NUM_STREAMS-1:0]    txfifo_rempty;   // Per-stream FIFO empty flags

// RX path signals (unchanged)
wire        rxfifo_wfull;
wire [31:0] rxfifo_wdata;
wire        rxfifo_wren;
wire [31:0] aligned_advb_rxdata;
wire [3:0]  aligned_advb_rxcharisk;
wire        crcerror;

//=========================================================================
// NEW: Generate Block — Instantiate NUM_STREAMS TX Async FIFOs
//
// Each stream gets its own independent async FIFO bridging from the
// system clock domain (clk) to the TX transceiver clock (tx_userclk2).
//
// The generate loop creates FIFO instances named tx_fifo[0], tx_fifo[1], etc.
// Each FIFO's write port connects to the corresponding slice of the
// wide input buses, and its read port connects to the corresponding
// slice of the internal buses feeding advbtx.
//=========================================================================
genvar g;
generate
  for (g = 0; g < NUM_STREAMS; g = g + 1) begin : tx_fifo
    asyncfifo #(
      .DATASIZE(32),
      .ADDRSIZE(11)                    // 2048 entries per stream
    ) fifo_inst (
      //=================================================================
      // Write side: system clock domain, driven by per-stream data source.
      // txfifo_wdata[g*32 +: 32] extracts the 32-bit slice for stream g.
      //=================================================================
      .wclk  (clk),
      .wrstn (rst_n),
      .winc  (txfifo_wren[g]),                  // Stream g's write enable
      .wdata (txfifo_wdata[g*32 +: 32]),        // Stream g's write data (32-bit slice)
      .wfull (txfifo_wfull[g]),                  // Stream g's full flag back to source

      //=================================================================
      // Read side: TX clock domain, driven by advbtx multi-stream module.
      // txfifo_rdata[g*32 +: 32] provides stream g's read data to advbtx.
      //=================================================================
      .rclk  (tx_userclk2),
      .rrstn (rst_n),
      .rinc  (txfifo_rden[g]),                   // Stream g's read enable from advbtx
      .rdata (txfifo_rdata[g*32 +: 32]),         // Stream g's read data to advbtx
      .rempty(txfifo_rempty[g])                  // Stream g's empty flag to advbtx
    );
  end
endgenerate

//=========================================================================
// MODIFIED: ADVB Multi-Stream Transmitter
//
// The advbtx module is now parameterized with NUM_STREAMS.
// Its FIFO interface accepts wide buses carrying all streams' signals.
// Internally it selects one stream at a time and sends its complete
// video frame before round-robin switching to the next stream.
//=========================================================================
advbtx #(
  .HACTIVE          (1920),
  .VACTIVE          (1080),
  .BytesPerPixel    (3),
  .FRAMERATE        (60),
  .VERTICALBLANKPRE (4),
  .VERTICALBLANKPOST(1),
  .NUM_STREAMS      (NUM_STREAMS)           // NEW: pass stream count
) transmit (
  .clk           (tx_userclk2),
  .rst           (rst_n),
  .advb_txdata   (advb_txdata),
  .txcharisk     (advb_txcharisk),
  .txfifo_empty  (txfifo_rempty),            // All streams' empty flags
  .txfifo_rd     (txfifo_rden),              // All streams' read enables
  .txfifo_rdata  (txfifo_rdata),             // All streams' read data
  .active_stream ()                          // Debug output (leave unconnected or route to ILA)
);

//=========================================================================
// RX Data Formatter (unchanged)
//=========================================================================
rxdata_formater align (
  .clk                    (rx_userclk2),
  .rst_n                  (rst_n),
  .advb_rxdata            (advb_rxdata),
  .advb_rxcharisk         (advb_rxcharisk),
  .aligned_advb_rxdata    (aligned_advb_rxdata),
  .aligned_advb_rxcharisk (aligned_advb_rxcharisk)
);

//=========================================================================
// ADVB Receiver (unchanged)
//=========================================================================
advbrx receive (
  .clk           (rx_userclk2),
  .rst_n         (rst_n),
  .advb_rxdata   (aligned_advb_rxdata),
  .advb_rxcharisk(aligned_advb_rxcharisk),
  .rxfifo_wfull  (rxfifo_wfull),
  .rxfifo_wdata  (rxfifo_wdata),
  .rxfifo_wren   (rxfifo_wren),
  .crcerror      (crcerror)
);

//=========================================================================
// RX Async FIFO (unchanged)
//=========================================================================
asyncfifo #(
  .DATASIZE(32),
  .ADDRSIZE(11)
) rx_fifo (
  .wclk  (rx_userclk2),
  .wrstn (rst_n),
  .winc  (rxfifo_wren),
  .wdata (rxfifo_wdata),
  .rclk  (clk),
  .rrstn (rst_n),
  .rinc  (rxfifo_rden),
  .rdata (rxfifo_rdata),
  .wfull (rxfifo_wfull),
  .rempty(rxfifo_rempty)
);

endmodule
