//=============================================================================
// arinc818_top.v  —  MULTI-STREAM ARINC 818 System Top-Level
//
// Instantiates NUM_STREAMS image pattern generators, each feeding its own
// TX FIFO through the multi-stream arinc818_core, which multiplexes them
// onto a single ADVB/GTH link.
//
// ╔═══════════════════════════════════════════════════════════════════════╗
// ║ MULTI-STREAM ARCHITECTURE:                                          ║
// ║                                                                     ║
// ║  Image Gen 0 ──► TX FIFO 0 ──┐                                     ║
// ║  Image Gen 1 ──► TX FIFO 1 ──┤──► ADVB TX ──► GTH ──► SFP+        ║
// ║  ...           ...            │   (round-robin)                     ║
// ║  Image Gen N ──► TX FIFO N ──┘                                     ║
// ║                                                                     ║
// ║  GTH RX ──► RX Formatter ──► ADVB RX ──► RX FIFO ──► RX Out       ║
// ╚═══════════════════════════════════════════════════════════════════════╝
//
// In a real application, each Image Gen would be replaced with a
// different video source (HDMI capture, sensor, frame buffer, etc.).
// Here we instantiate distinct pattern generators to demonstrate the
// multi-stream multiplexing.
//=============================================================================

`timescale 1ns / 1ps

module arinc818_top #(
  //=========================================================================
  // NEW TOP-LEVEL PARAMETER: Number of multiplexed video streams.
  // Change this to add or remove streams. All sub-modules scale automatically.
  //=========================================================================
  parameter NUM_STREAMS = 2
)(
  input  wire sysclk_p,
  input  wire sysclk_n,
  input  wire mgtrefclk_p,
  input  wire mgtrefclk_n,
  input  wire sfp_rx_n,
  input  wire sfp_rx_p,
  output wire sfp_tx_n,
  output wire sfp_tx_p,
  output wire sfp_tx_disable,
  input  wire cpu_reset,
  output wire cplllock_out,
  output wire led1
);

//=========================================================================
// Internal Wires
//=========================================================================
wire        drp_clk25M;
wire        mgt_clk212M5;
wire        clk_106M25;
wire        tx_userclk2;
wire        rx_userclk2;
wire [31:0] advb_txdata;
wire [3:0]  advb_txcharisk;
wire [31:0] advb_rxdata;
wire [3:0]  advb_rxcharisk;
wire        rxfifo_rempty;
wire        image_rden;
wire [31:0] image_rdata;
wire        locked;
wire        rst_n;

//=========================================================================
// NEW: Per-stream wires for connecting image generators to core.
//
// txfifo_wfull  [NUM_STREAMS-1:0]      — full flags, one per FIFO
// image_wdata   [NUM_STREAMS*32-1:0]   — concatenated 32-bit pixel data
// image_wren    [NUM_STREAMS-1:0]      — write enables, one per stream
//=========================================================================
wire [NUM_STREAMS-1:0]    txfifo_wfull;   // Backpressure from each TX FIFO
wire [NUM_STREAMS*32-1:0] image_wdata;    // Concatenated write data from all generators
wire [NUM_STREAMS-1:0]    image_wren;     // Write enable from each generator

//=========================================================================
// Reset & SFP (unchanged)
//=========================================================================
assign rst_n          = locked & !cpu_reset;
assign sfp_tx_disable = 1'b0;            // TX enabled for SAM G3

//=========================================================================
// Clock Wizard PLL (unchanged)
//=========================================================================
clk_wiz_0 pll (
  .clk_out1 (mgt_clk212M5),
  .clk_out2 (drp_clk25M),
  .clk_out3 (clk_106M25),
  .locked   (locked),
  .clk_in1_p(sysclk_p),
  .clk_in1_n(sysclk_n)
);

//=========================================================================
// NEW: Generate Block — NUM_STREAMS Image Pattern Generators
//
// Each generator produces an independent 1920x1080 color-bar pattern.
// In a real system, these would be different video sources (HDMI, sensor,
// frame buffer, etc.).
//
// The generate loop creates u_img_gen[0], u_img_gen[1], etc.
// Each generator's wdata output connects to its 32-bit slice of the
// wide image_wdata bus, and its wfull input comes from the
// corresponding TX FIFO's full flag.
//
// NOTE: To make each stream visually distinguishable on the receiver,
// you could add a PATTERN_OFFSET parameter to image_pattern_gen and
// set it to g (the stream index), giving each stream a different
// color bar phase.
//=========================================================================
genvar g;
generate
  for (g = 0; g < NUM_STREAMS; g = g + 1) begin : u_img_gen
    image_pattern_gen #(
      .HACTIVE      (1920),
      .VACTIVE      (1080),
      .BytesPerPixel(3)
    ) gen_inst (
      .clk   (clk_106M25),
      .rst_n (rst_n),
      //=================================================================
      // txfifo_wfull[g] — backpressure from this stream's TX FIFO.
      // When asserted, the generator pauses writing.
      //=================================================================
      .wfull (txfifo_wfull[g]),
      //=================================================================
      // image_wdata[g*32 +: 32] — this stream's 32-bit write data slice.
      // The +: operator selects 32 bits starting at bit g*32.
      //=================================================================
      .wdata (image_wdata[g*32 +: 32]),
      //=================================================================
      // image_wren[g] — this stream's write enable.
      //=================================================================
      .winc  (image_wren[g]),
      //=================================================================
      // frame_sync — start-of-frame pulse (not used in TX path, left
      // unconnected). Could be routed to debug logic if needed.
      //=================================================================
      .frame_sync ()
    );
  end
endgenerate

//=========================================================================
// MODIFIED: Multi-Stream ARINC 818 Core
//
// Parameterized with NUM_STREAMS. Contains NUM_STREAMS TX FIFOs
// and the multi-stream advbtx. All streams are multiplexed onto
// the single ADVB output.
//=========================================================================
arinc818_core #(
  .NUM_STREAMS(NUM_STREAMS)
) transmit_receive (
  .clk           (clk_106M25),
  .tx_userclk2   (tx_userclk2),
  .rx_userclk2   (rx_userclk2),
  .rst_n         (rst_n),
  //=================================================================
  // Wide per-stream TX FIFO interface:
  //=================================================================
  .txfifo_wfull  (txfifo_wfull),         // [NUM_STREAMS-1:0]
  .txfifo_wdata  (image_wdata),          // [NUM_STREAMS*32-1:0]
  .txfifo_wren   (image_wren),           // [NUM_STREAMS-1:0]
  //=================================================================
  // Single ADVB link (unchanged):
  //=================================================================
  .advb_txdata   (advb_txdata),
  .advb_txcharisk(advb_txcharisk),
  .advb_rxdata   (advb_rxdata),
  .advb_rxcharisk(advb_rxcharisk),
  .rxfifo_rempty (rxfifo_rempty),
  .rxfifo_rden   (image_rden),
  .rxfifo_rdata  (image_rdata)
);

//=========================================================================
// GTH Transceiver Top (unchanged)
//=========================================================================
arinc818_trans_top transceiver_inst (
  .mgtrefclk0_x1y3_p    (mgtrefclk_p),
  .mgtrefclk0_x1y3_n    (mgtrefclk_n),
  .ch0_gthrxn_in        (sfp_rx_n),
  .ch0_gthrxp_in        (sfp_rx_p),
  .ch0_gthtxn_out       (sfp_tx_n),
  .ch0_gthtxp_out       (sfp_tx_p),
  .reset_clk_freerun_in (drp_clk25M),
  .reset_all_in         (!rst_n),
  .userclk_tx_usrclk2   (tx_userclk2),
  .userclk_rx_usrclk2   (rx_userclk2),
  .advb_txdata          (advb_txdata),
  .advb_txcharisk       (advb_txcharisk),
  .advb_rxdata          (advb_rxdata),
  .advb_rxcharisk       (advb_rxcharisk),
  .cplllock_out         (cplllock_out)
);

//=========================================================================
// RX FIFO Read Logic (unchanged)
//=========================================================================
assign image_rden = rxfifo_rempty ? 1'b0 : 1'b1;

//=========================================================================
// LED Status (unchanged)
//=========================================================================
assign led1 = (image_rdata == 32'hA5) ? 1'b0 : 1'b1;

endmodule
