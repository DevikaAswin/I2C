//=============================================================================
// advbtx.v  —  MULTI-STREAM ARINC 818 (ADVB) Transmitter
//
// Parameterizable multi-stream support:  NUM_STREAMS independent video
// inputs are time-division-multiplexed onto a single ADVB link using
// round-robin scheduling per complete video frame.
//
// Architecture per stream:
//   SOFi → Header(6) → Container(22) → Ancillary(4) → CRC → EOF   (Obj 0)
//   SOFn → Header(6) → Payload(480) → CRC → EOF                   (Obj 2)
//   ...repeat for all lines x frames_per_line...
//   Last frame uses EOF_T to mark end of video frame.
//
// After completing one full video frame for stream N, the transmitter
// advances to stream (N+1) % NUM_STREAMS.
//
// Each stream has independent:
//   - containercount (video frame counter)
//   - seq_count      (ADVB frame sequence within container)
//   - lineindex      (which video line is being sent)
//   - sublineindex   (which ADVB frame within the line)
//   - object0 flag   (needs Object 0 container frame)
//   - lastframe flag (marks final frame in video frame)
//
// The FIFO interface is widened to NUM_STREAMS parallel FIFOs:
//   txfifo_empty [NUM_STREAMS-1:0]  — one empty flag per stream
//   txfifo_rd    [NUM_STREAMS-1:0]  — one read-enable per stream
//   txfifo_rdata [NUM_STREAMS*32-1:0] — concatenated 32-bit read data
//
// The frame header Source ID field encodes the stream index so the
// receiver can demultiplex streams.
//=============================================================================

`timescale 1ns / 1ps

module advbtx #(
  parameter HACTIVE              = 1920,        // Horizontal active pixels
  parameter VACTIVE              = 1080,        // Vertical active lines
  parameter BytesPerPixel        = 3,           // Bytes per pixel (RGB24)
  parameter FRAMERATE            = 60,          // Video frame rate
  parameter VERTICALBLANKPRE     = 4,           // Vertical blank lines before active
  parameter VERTICALBLANKPOST    = 1,           // Vertical blank lines after active
  parameter HORIZONTALIDLECYCLES = 6,           // Idle cycles between ADVB frames
  //=========================================================================
  // NEW PARAMETER: Number of independent video streams to multiplex.
  // Set to 1 for backward-compatible single-stream behavior.
  //=========================================================================
  parameter NUM_STREAMS          = 2            // Number of multiplexed streams
)(
  input             clk,                        // TX clock (tx_userclk2)
  input             rst,                        // Active-low reset

  //=========================================================================
  // CHANGED: FIFO interface is now NUM_STREAMS-wide.
  // Each stream has its own empty flag, read-enable, and read-data bus.
  //=========================================================================
  input  [NUM_STREAMS-1:0]      txfifo_empty,   // Per-stream FIFO empty flags
  output reg [NUM_STREAMS-1:0]  txfifo_rd,       // Per-stream FIFO read enables
  input  [NUM_STREAMS*32-1:0]   txfifo_rdata,    // Per-stream FIFO read data (concatenated)

  //=========================================================================
  // ADVB link output (unchanged — single physical link)
  //=========================================================================
  output reg [31:0] advb_txdata,                 // 32-bit data to transceiver
  output reg [3:0]  txcharisk,                   // K-character flags

  //=========================================================================
  // NEW OUTPUT: Current active stream index (for debug/monitoring)
  //=========================================================================
  output [$clog2(NUM_STREAMS)-1:0] active_stream // Which stream is currently transmitting
);

//=========================================================================
// Derived Parameters (unchanged from single-stream)
//=========================================================================
localparam PAYLOADBYTESPERFRAME = 1920;
localparam BYTESPERLINE   = (HACTIVE * BytesPerPixel);
localparam WORDSPERLINE   = (BYTESPERLINE / 4);
localparam HEADERWORDS    = 6;
localparam CONTAINERWORDS = 22;
localparam ANCILLARYWORDS = 4;
localparam FRAMESPERLINE  = BYTESPERLINE / PAYLOADBYTESPERFRAME;
localparam PAYLOADWORDS   = PAYLOADBYTESPERFRAME / 4;
localparam TOTALOBJ2FRAMES = VACTIVE * FRAMESPERLINE;
localparam VTOTAL         = VACTIVE + VERTICALBLANKPRE + VERTICALBLANKPOST;

//=========================================================================
// NEW: Stream index width — uses $clog2 to get minimum bits needed.
// For NUM_STREAMS=2, STREAM_IDX_W=1. For NUM_STREAMS=4, STREAM_IDX_W=2.
//=========================================================================
localparam STREAM_IDX_W = (NUM_STREAMS == 1) ? 1 : $clog2(NUM_STREAMS);

//=========================================================================
// State Encoding (unchanged)
//=========================================================================
localparam IDLE        = 4'd0;
localparam SENDSOF     = 4'd1;
localparam SENDHDR     = 4'd2;
localparam SENDCONT    = 4'd3;
localparam SENDANC     = 4'd4;
localparam SENDPAYLOAD = 4'd5;
localparam SENDCRC     = 4'd6;
localparam SENDEOF     = 4'd7;

//=========================================================================
// Ordered Set Constants (unchanged)
//=========================================================================
localparam IDLEWORD = 32'hB5B595BC;
localparam SOFIWORD = 32'h5757BFBC;
localparam SOFNWORD = 32'h4F4FB7BC;
localparam EOFNWORD = 32'h4E4E95BC;
localparam EOFTWORD = 32'h4B4B95BC;

//=========================================================================
// Internal Signals — shared across streams (only one stream active at a time)
//=========================================================================
wire [13:0] VACT = VACTIVE;
wire [13:0] HACT = HACTIVE;

reg [4:0]  state;                // FSM state register
reg [4:0]  nextstate;            // FSM next-state
reg [31:0] crcaccum;             // CRC accumulator (reset per frame)
reg [9:0]  wordcounter;          // Word counter within a state
reg [10:0] count;                // Blanking counter
reg [2:0]  idlecounter;          // Inter-frame idle counter

//=========================================================================
// NEW: Current stream index register.
// This register selects which stream's per-stream state and FIFO are active.
// It advances to (current_stream + 1) % NUM_STREAMS after each complete
// video frame (after sending EOF_T at the last line/subline of a frame).
//=========================================================================
reg [STREAM_IDX_W-1:0] current_stream;

//=========================================================================
// NEW: Per-stream state arrays.
// Each stream independently tracks its own position within the video frame.
// These are register arrays indexed by current_stream.
//
// Using unpacked arrays: reg [width] name [0:NUM_STREAMS-1]
// means we have NUM_STREAMS copies of each register.
//=========================================================================
reg [31:0] containercount [0:NUM_STREAMS-1]; // Per-stream video frame counter
reg [15:0] seq_count      [0:NUM_STREAMS-1]; // Per-stream ADVB frame sequence number
reg [15:0] lineindex      [0:NUM_STREAMS-1]; // Per-stream current video line number
reg [1:0]  sublineindex   [0:NUM_STREAMS-1]; // Per-stream sub-frame index within line
reg        object0        [0:NUM_STREAMS-1]; // Per-stream "need Object 0" flag
reg        lastframe      [0:NUM_STREAMS-1]; // Per-stream "last frame" flag

//=========================================================================
// NEW: Mux to select the read-data from the active stream's FIFO.
// txfifo_rdata is a flat bus [NUM_STREAMS*32-1:0], so for stream i,
// the data occupies bits [i*32 +: 32].
//=========================================================================
wire [31:0] active_txfifo_rdata;
assign active_txfifo_rdata = txfifo_rdata[current_stream*32 +: 32];

//=========================================================================
// NEW: Output the current active stream index for debug/monitoring.
//=========================================================================
assign active_stream = current_stream;

//=========================================================================
// CRC-32 Function (unchanged — Fibre Channel polynomial)
//=========================================================================
function [31:0] nextcrc32;
  input [31:0] crc;
  input [31:0] data;
  integer p;
  reg [31:0] c;
  begin
    c = crc;
    for (p = 0; p < 32; p = p + 1) begin
      c = (c[31] ^ data[31-p]) ? ((c << 1) ^ 32'h04C11DB7) : (c << 1);
      nextcrc32 = c;
    end
  end
endfunction

//=========================================================================
// Ancillary Header Function (unchanged)
//=========================================================================
function [31:0] ancillaryheader;
  input [2:0] index;
  begin
    case(index)
      3'd0    : ancillaryheader = {VACT, HACT, 4'b0000};
      3'd1    : ancillaryheader = 32'h10008888;
      3'd2    : ancillaryheader = 32'b0;
      3'd3    : ancillaryheader = 32'b0;
      default : ancillaryheader = 32'b0;
    endcase
  end
endfunction

//=========================================================================
// Container Header Function (unchanged, reads from per-stream containercount)
// NOTE: containercount is accessed via s_containercount alias below.
//=========================================================================
// We cannot pass array elements directly into functions in Verilog-2001,
// so we use intermediate wires that select the current stream's state.
//=========================================================================
wire [31:0] s_containercount;   // Current stream's container count
wire [15:0] s_seq_count;        // Current stream's sequence count
wire [15:0] s_lineindex;        // Current stream's line index
wire [1:0]  s_sublineindex;     // Current stream's sub-line index
wire        s_object0;          // Current stream's object0 flag
wire        s_lastframe;        // Current stream's lastframe flag

assign s_containercount = containercount[current_stream];
assign s_seq_count      = seq_count[current_stream];
assign s_lineindex      = lineindex[current_stream];
assign s_sublineindex   = sublineindex[current_stream];
assign s_object0        = object0[current_stream];
assign s_lastframe      = lastframe[current_stream];

function [31:0] containerheader;
  input [4:0] index;
  input [31:0] cont_count;    // pass in the container count
  begin
    case(index)
      5'd0  : containerheader = cont_count;
      5'd1  : containerheader = 32'h0;
      5'd2  : containerheader = 32'h0;
      5'd3  : containerheader = 32'h0;
      5'd4  : containerheader = 32'h10000;
      5'd5  : containerheader = {8'h00, 8'd4, 16'h0000};  // PRE=4
      5'd6  : containerheader = {8'h50, 8'b0, 16'hd000};
      5'd7  : containerheader = 32'h10;
      5'd8  : containerheader = 32'h58;
      5'd9  : containerheader = 32'b0;
      5'd10 : containerheader = 32'b0;
      5'd11 : containerheader = 32'b0;
      5'd12 : containerheader = 32'b0;
      5'd13 : containerheader = 32'b0;
      5'd14 : containerheader = 32'b0;
      5'd15 : containerheader = 32'b0;
      5'd16 : containerheader = 32'b0;
      5'd17 : containerheader = 32'b0;
      5'd18 : containerheader = 32'b0;
      5'd19 : containerheader = 32'b0;
      5'd20 : containerheader = 32'b0;
      5'd21 : containerheader = 32'b0;
      default: containerheader = 32'b0;
    endcase
  end
endfunction

//=========================================================================
// MODIFIED Frame Header Function
// Word 1 now encodes the stream index in the Source ID field [23:16].
// This lets the receiver identify which stream each frame belongs to.
//
// Word 2 uses s_lastframe via the lastframe_in input.
// Word 3 uses s_containercount and s_seq_count via inputs.
//=========================================================================
function [31:0] frameheader;
  input [2:0]  index;
  input [STREAM_IDX_W-1:0] stream_id;     // NEW: which stream this frame belongs to
  input        lastframe_in;               // current stream's lastframe
  input [31:0] cont_count_in;             // current stream's container count
  input [15:0] seq_count_in;              // current stream's sequence count
  begin
    case(index)
      3'd0 : frameheader = {8'h44, 24'b0};
      //=================================================================
      // MODIFIED: Source ID byte [23:16] now carries the stream index.
      // Receiver uses this to demultiplex incoming frames to the
      // correct output stream.  Bits [15:0] are reserved (zero).
      //=================================================================
      3'd1 : frameheader = {8'b0, stream_id[STREAM_IDX_W-1:0], {(8-STREAM_IDX_W){1'b0}}, 16'b0};
      3'd2 : if (lastframe_in == 1'b1)
               frameheader = {8'h61, 24'h380000};      // END_SEQ set
             else
               frameheader = {8'h61, 24'h300000};      // Normal
      3'd3 : frameheader = {cont_count_in[7:0], 8'b0, seq_count_in};
      3'd4 : frameheader = {16'hFFFF, 16'hFFFF};
      3'd5 : frameheader = 32'b0;
      default : frameheader = 32'b0;
    endcase
  end
endfunction

//=========================================================================
// State Register (unchanged logic, asynchronous active-low reset)
//=========================================================================
always @(posedge clk or negedge rst) begin
  if (!rst)
    state <= IDLE;
  else
    state <= nextstate;
end

//=========================================================================
// Next-State Logic (combinational)
// MODIFIED: Uses s_* aliases to read current stream's state.
// Uses txfifo_empty[current_stream] to check current stream's FIFO.
//=========================================================================
always @(*) begin
  nextstate = state;
  case(state)
    IDLE: begin
      //=================================================================
      // Blanking/idle logic uses the CURRENT STREAM's lineindex.
      // The FIFO empty check is on the CURRENT STREAM's FIFO.
      //=================================================================
      if (s_lineindex < VERTICALBLANKPRE)
        nextstate = IDLE;
      else if (s_object0 == 1'b1 && s_lineindex < (VERTICALBLANKPOST + VERTICALBLANKPRE + 1))
        nextstate = IDLE;
      else begin
        if (idlecounter == 3'b101 && txfifo_empty[current_stream] == 1'b0)
          nextstate = SENDSOF;
        else
          nextstate = IDLE;
      end
    end

    SENDSOF:
      nextstate = SENDHDR;

    SENDHDR: begin
      if (wordcounter == (HEADERWORDS - 1)) begin
        if (s_object0 == 1'b0)
          nextstate = SENDCONT;
        else
          nextstate = SENDPAYLOAD;
      end
      else
        nextstate = SENDHDR;
    end

    SENDPAYLOAD: begin
      if (wordcounter == (PAYLOADWORDS - 1))
        nextstate = SENDCRC;
      else
        nextstate = SENDPAYLOAD;
    end

    SENDCONT: begin
      if (wordcounter == (CONTAINERWORDS - 1))
        nextstate = SENDANC;
      else
        nextstate = SENDCONT;
    end

    SENDANC: begin
      if (wordcounter == (ANCILLARYWORDS - 1))
        nextstate = SENDCRC;
      else
        nextstate = SENDANC;
    end

    SENDCRC:
      nextstate = SENDEOF;

    SENDEOF:
      nextstate = IDLE;

    default:
      nextstate = IDLE;
  endcase
end

//=========================================================================
// Initialization loop variable for per-stream array reset
//=========================================================================
integer s;  // Loop variable for iterating over streams during reset

//=========================================================================
// Output & Datapath Logic (clocked)
//
// KEY MULTI-STREAM CHANGES:
//   1. All per-stream state reads/writes use [current_stream] index.
//   2. txfifo_rd is indexed to only assert read on current stream's FIFO.
//   3. FIFO read data comes from active_txfifo_rdata (muxed by current_stream).
//   4. In SENDEOF, after completing a full video frame (EOF_T), the
//      current_stream register advances to the next stream.
//=========================================================================
always @(posedge clk or negedge rst) begin
  if (!rst) begin
    advb_txdata    <= IDLEWORD;
    txcharisk      <= 4'b0001;
    wordcounter    <= 0;
    crcaccum       <= 32'hFFFFFFFF;
    idlecounter    <= 0;
    count          <= 0;
    //===================================================================
    // NEW: Reset current_stream to stream 0.
    //===================================================================
    current_stream <= {STREAM_IDX_W{1'b0}};
    //===================================================================
    // NEW: Reset all per-stream FIFO read enables to inactive.
    //===================================================================
    txfifo_rd      <= {NUM_STREAMS{1'b0}};
    //===================================================================
    // NEW: Initialize every stream's state to starting conditions.
    // Each stream begins at lineindex=0, sublineindex=0, needing
    // Object 0, with container count 0 and sequence 0.
    //===================================================================
    for (s = 0; s < NUM_STREAMS; s = s + 1) begin
      containercount[s] <= 32'd0;
      seq_count[s]      <= 16'd0;
      lineindex[s]      <= 16'd0;
      sublineindex[s]   <= 2'd0;
      object0[s]        <= 1'b0;        // Start with Object 0 frame
      lastframe[s]      <= 1'b0;
    end
  end
  else begin
    case(state)
      //-------------------------------------------------------------------
      // IDLE: Send idle words, count through vertical blank or idle gaps.
      // All reads from per-stream state use [current_stream].
      //-------------------------------------------------------------------
      IDLE: begin
        advb_txdata <= IDLEWORD;
        txcharisk   <= 4'b0001;
        //=================================================================
        // CHANGED: Deassert read-enable for ALL streams during idle.
        // We clear the entire txfifo_rd vector, not just one bit.
        //=================================================================
        txfifo_rd   <= {NUM_STREAMS{1'b0}};

        if (lineindex[current_stream] < VERTICALBLANKPRE) begin
          //===============================================================
          // Vertical blank pre-active region: count idle cycles,
          // then advance the CURRENT STREAM's lineindex.
          //===============================================================
          if (count == 11'd1024) begin
            lineindex[current_stream] <= lineindex[current_stream] + 1;
            count <= 0;
          end
          else begin
            count <= count + 1;
          end
        end
        else begin
          //===============================================================
          // Inter-frame idle gap: count HORIZONTALIDLECYCLES idles
          // before allowing SENDSOF transition.
          //===============================================================
          if (idlecounter == 3'b110)
            idlecounter <= 0;
          else
            idlecounter <= idlecounter + 1;
        end
      end

      //-------------------------------------------------------------------
      // SENDSOF: Send Start-of-Frame ordered set.
      // Reset CRC at start of every new ADVB frame.
      // Uses current stream's object0 and seq_count.
      //-------------------------------------------------------------------
      SENDSOF: begin
        txcharisk <= 4'b0001;
        crcaccum  <= 32'hFFFFFFFF;

        if (object0[current_stream] == 1'b0) begin
          //===============================================================
          // Object 0 (Container) frame: send SOF_I, reset seq counter.
          // Set object0 flag so subsequent frames become Object 2.
          //===============================================================
          seq_count[current_stream] <= 0;
          advb_txdata               <= SOFIWORD;
          object0[current_stream]   <= 1'b1;
          lastframe[current_stream] <= 1'b0;
        end
        else begin
          //===============================================================
          // Object 2 (Payload) frame: send SOF_N, increment seq counter.
          //===============================================================
          seq_count[current_stream] <= seq_count[current_stream] + 1;
          advb_txdata               <= SOFNWORD;
        end
      end

      //-------------------------------------------------------------------
      // SENDHDR: Send 6-word Fibre Channel frame header.
      // MODIFIED: Passes current_stream to frameheader() so the
      // Source ID field carries the stream index.
      //-------------------------------------------------------------------
      SENDHDR: begin
        //=================================================================
        // CHANGED: frameheader now receives stream ID and per-stream state
        // so the receiver can identify which stream each frame belongs to.
        //=================================================================
        advb_txdata <= frameheader(
          wordcounter[2:0],
          current_stream,
          lastframe[current_stream],
          containercount[current_stream],
          seq_count[current_stream]
        );
        txcharisk   <= 4'b0000;
        if (wordcounter == (HEADERWORDS - 1)) begin
          wordcounter <= 0;
          if (object0[current_stream] == 1'b1) begin
            //=============================================================
            // CHANGED: Assert read enable ONLY on the current stream's
            // FIFO bit. All other streams remain deasserted.
            //=============================================================
            txfifo_rd                  <= {NUM_STREAMS{1'b0}};
            txfifo_rd[current_stream]  <= 1'b1;
          end
        end
        else begin
          wordcounter <= wordcounter + 1;
        end
      end

      //-------------------------------------------------------------------
      // SENDPAYLOAD: Send pixel data from current stream's FIFO.
      // MODIFIED: Uses active_txfifo_rdata (muxed by current_stream).
      //-------------------------------------------------------------------
      SENDPAYLOAD: begin
        //=================================================================
        // CHANGED: Read data from the MUXed active stream's FIFO output
        // instead of a single txfifo_rdata wire.
        //=================================================================
        advb_txdata <= active_txfifo_rdata;
        txcharisk   <= 4'b0000;
        crcaccum    <= nextcrc32(crcaccum, active_txfifo_rdata);
        wordcounter <= wordcounter + 1;
        if (wordcounter >= (PAYLOADWORDS - 1)) begin
          //===============================================================
          // CHANGED: Deassert read-enable on the current stream's FIFO
          // when payload is complete.
          //===============================================================
          txfifo_rd <= {NUM_STREAMS{1'b0}};
        end
        else begin
          txfifo_rd                 <= {NUM_STREAMS{1'b0}};
          txfifo_rd[current_stream] <= 1'b1;
        end
      end

      //-------------------------------------------------------------------
      // SENDCONT: Send 22-word container header, update CRC.
      // Uses current stream's containercount via s_containercount.
      //-------------------------------------------------------------------
      SENDCONT: begin
        advb_txdata <= containerheader(wordcounter, containercount[current_stream]);
        txcharisk   <= 4'b0000;
        crcaccum    <= nextcrc32(crcaccum, containerheader(wordcounter, containercount[current_stream]));
        if (wordcounter == (CONTAINERWORDS - 1))
          wordcounter <= 0;
        else
          wordcounter <= wordcounter + 1;
      end

      //-------------------------------------------------------------------
      // SENDANC: Send 4-word ancillary data, update CRC.
      // (Unchanged — ancillary header is the same for all streams)
      //-------------------------------------------------------------------
      SENDANC: begin
        advb_txdata <= ancillaryheader(wordcounter);
        txcharisk   <= 4'b0000;
        crcaccum    <= nextcrc32(crcaccum, ancillaryheader(wordcounter));
        if (wordcounter == (ANCILLARYWORDS - 1))
          wordcounter <= 0;
        else
          wordcounter <= wordcounter + 1;
      end

      //-------------------------------------------------------------------
      // SENDCRC: Output accumulated CRC-32. (Unchanged)
      //-------------------------------------------------------------------
      SENDCRC: begin
        advb_txdata <= crcaccum;
        txcharisk   <= 4'b0000;
      end

      //-------------------------------------------------------------------
      // SENDEOF: Send End-of-Frame, advance counters.
      //
      // KEY MULTI-STREAM LOGIC:
      //   When the last ADVB frame of a complete video frame is sent
      //   (last line, last subline → EOF_T), the current_stream register
      //   advances to the next stream via round-robin.
      //-------------------------------------------------------------------
      SENDEOF: begin
        txcharisk <= 4'b0001;

        if ((lineindex[current_stream] == VTOTAL - 1)
            && (sublineindex[current_stream] == FRAMESPERLINE - 1))
        begin
          //===============================================================
          // LAST FRAME of entire video image for this stream:
          //   - Send EOF_T (terminate)
          //   - Increment this stream's container count
          //   - Reset line/subline indices for this stream
          //   - Clear object0 so next time this stream starts with Obj0
          //   - Set lastframe for this stream
          //
          // *** STREAM SWITCH: Advance current_stream to next stream ***
          // This is the ONLY place where stream switching occurs,
          // ensuring each stream completes a full video frame before
          // the link moves to the next stream.
          //===============================================================
          advb_txdata <= EOFTWORD;
          containercount[current_stream] <= containercount[current_stream] + 1;
          sublineindex[current_stream]   <= 0;
          lineindex[current_stream]      <= 0;
          object0[current_stream]        <= 1'b0;
          lastframe[current_stream]      <= 1'b1;

          //===============================================================
          // ROUND-ROBIN STREAM ADVANCE:
          // Move to stream (current + 1) mod NUM_STREAMS.
          // For 2 streams this toggles 0→1→0→1...
          // For 4 streams this cycles 0→1→2→3→0→1...
          //
          // Also reset the blanking counter (count) for the next stream
          // since it will need to go through its own vertical blank.
          //===============================================================
          if (current_stream == NUM_STREAMS - 1)
            current_stream <= {STREAM_IDX_W{1'b0}};  // Wrap around to stream 0
          else
            current_stream <= current_stream + 1;     // Advance to next stream
          count <= 0;
        end
        else if (sublineindex[current_stream] < (FRAMESPERLINE - 1))
        begin
          //===============================================================
          // More sub-frames remaining for this line — no stream switch.
          //===============================================================
          advb_txdata <= EOFNWORD;
          sublineindex[current_stream] <= sublineindex[current_stream] + 1;
        end
        else begin
          //===============================================================
          // Line complete, advance to next line — no stream switch.
          //===============================================================
          advb_txdata <= EOFNWORD;
          sublineindex[current_stream] <= 0;
          lineindex[current_stream]    <= lineindex[current_stream] + 1;
        end
      end

      default: begin
        advb_txdata <= IDLEWORD;
        txcharisk   <= 4'b0001;
      end
    endcase
  end
end

endmodule
