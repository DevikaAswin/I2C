# ARINC 818 Multi-Stream Transmitter — Complete Guide

## Overview

This document explains **every line that was added or changed** to add multi-stream support to the ARINC 818 ADVB transmitter. The design allows `NUM_STREAMS` independent video inputs to be **time-division multiplexed** onto a single ADVB link using round-robin scheduling.

> [!IMPORTANT]
> The original single-stream behavior is preserved when `NUM_STREAMS = 1`. Setting it to 2, 4, or any value scales the design automatically.

---

## Architecture: Before vs After

### Before (Single-Stream)
```
Image Gen ──► TX FIFO ──► ADVB TX ──► GTH ──► SFP+
```

### After (Multi-Stream)
```
Image Gen 0 ──► TX FIFO 0 ──┐
Image Gen 1 ──► TX FIFO 1 ──┤──► ADVB TX (round-robin) ──► GTH ──► SFP+
...                          │
Image Gen N ──► TX FIFO N ──┘
```

---

## Files Modified

| File | Change Type | Summary |
|------|-------------|---------|
| `advbtx.v` | **Major rewrite** | Per-stream state arrays, stream muxing, round-robin switching |
| `arinc818_core.v` | **Major rewrite** | Generate block for N TX FIFOs, wide bus interfaces |
| `arinc818_top.v` | **Major rewrite** | Generate block for N image generators, parameterized |
| `tb_arinc818_multistream.v` | **New file** | Multi-stream testbench with monitor |
| `asyncfifo.v` | Unchanged | Copied from original |
| `rxdata_formater.v` | Unchanged | Copied from original |
| `advbrx.v` | Unchanged | Copied from original |
| `image_pattern_gen.v` | Unchanged | Copied from original |

---

## Detailed Line-by-Line Explanation

### 1. `advbtx.v` — Multi-Stream Transmitter

#### New Parameter

```verilog
parameter NUM_STREAMS = 2     // Number of multiplexed streams
```
**Why:** Makes the design configurable. Set to 1 for original behavior, 2+ for multi-stream.

#### Stream Index Width

```verilog
localparam STREAM_IDX_W = (NUM_STREAMS == 1) ? 1 : $clog2(NUM_STREAMS);
```
**Why:** Calculates the minimum number of bits needed to address all streams. For 2 streams, this is 1 bit. For 4 streams, 2 bits. The ternary handles the edge case where `$clog2(1) = 0`.

#### Widened FIFO Interface

```verilog
input  [NUM_STREAMS-1:0]      txfifo_empty,   // One empty flag per stream
output reg [NUM_STREAMS-1:0]  txfifo_rd,      // One read-enable per stream
input  [NUM_STREAMS*32-1:0]   txfifo_rdata,   // Concatenated 32-bit data
```
**Why:** Instead of a single `txfifo_empty` bit and single `txfifo_rdata[31:0]`, we now have N-wide buses. Each stream's 32-bit data occupies bits `[i*32 +: 32]` in the concatenated bus.

#### Current Stream Register

```verilog
reg [STREAM_IDX_W-1:0] current_stream;
```
**Why:** This register selects which stream is currently being serviced. It only changes when a complete video frame finishes (at EOF_T). This ensures one stream's entire frame is sent before switching.

#### Per-Stream State Arrays

```verilog
reg [31:0] containercount [0:NUM_STREAMS-1]; // Video frame counter per stream
reg [15:0] seq_count      [0:NUM_STREAMS-1]; // ADVB frame sequence per stream
reg [15:0] lineindex      [0:NUM_STREAMS-1]; // Current line per stream
reg [1:0]  sublineindex   [0:NUM_STREAMS-1]; // Sub-frame index per stream
reg        object0        [0:NUM_STREAMS-1]; // Need Object 0 flag per stream
reg        lastframe      [0:NUM_STREAMS-1]; // Last frame flag per stream
```
**Why:** Each stream independently tracks its position within a video frame. When we switch from Stream 0 to Stream 1, Stream 0's state is preserved. When we come back to Stream 0, it continues exactly where it left off.

#### Active Stream Data Mux

```verilog
wire [31:0] active_txfifo_rdata;
assign active_txfifo_rdata = txfifo_rdata[current_stream*32 +: 32];
```
**Why:** The flat concatenated bus `txfifo_rdata` needs to be sliced to get the current stream's 32-bit data. The Verilog `+:` operator selects 32 bits starting at position `current_stream * 32`.

#### Convenience Aliases for Current Stream

```verilog
wire [31:0] s_containercount;
assign s_containercount = containercount[current_stream];
// ... similar for seq_count, lineindex, sublineindex, object0, lastframe
```
**Why:** The next-state logic (combinational `always @(*)` block) needs to read the current stream's state. These wires provide clean access without repeating `[current_stream]` everywhere.

#### Modified Frame Header — Stream ID

```verilog
function [31:0] frameheader;
  input [2:0]  index;
  input [STREAM_IDX_W-1:0] stream_id;     // NEW
  input        lastframe_in;
  input [31:0] cont_count_in;
  input [15:0] seq_count_in;
  begin
    case(index)
      // ...
      3'd1 : frameheader = {8'b0, stream_id[STREAM_IDX_W-1:0], 
                            {(8-STREAM_IDX_W){1'b0}}, 16'b0};
      // ...
    endcase
  end
endfunction
```
**Why:** Word 1 of the Fibre Channel frame header contains the Source ID. We encode the stream index in bits [23:16] so the receiver can demultiplex frames. The padding `{(8-STREAM_IDX_W){1'b0}}` fills remaining bits with zeros.

#### Per-Stream FIFO Read Enable

```verilog
// In SENDHDR, when object0 is set (payload frame):
txfifo_rd                  <= {NUM_STREAMS{1'b0}};   // Clear ALL streams first
txfifo_rd[current_stream]  <= 1'b1;                  // Enable ONLY current stream
```
**Why:** Only one FIFO should be read at a time. We first clear all bits, then set the bit for the active stream. This is a two-line pattern that works for any NUM_STREAMS.

#### Reading Active Stream's FIFO Data

```verilog
// In SENDPAYLOAD:
advb_txdata <= active_txfifo_rdata;    // Was: txfifo_rdata
crcaccum    <= nextcrc32(crcaccum, active_txfifo_rdata);
```
**Why:** The payload data now comes from the muxed output that selects the current stream's FIFO data.

#### Container Header with Stream's Count

```verilog
// In SENDCONT:
advb_txdata <= containerheader(wordcounter, containercount[current_stream]);
```
**Why:** The container header function now takes the container count as a parameter so each stream uses its own frame counter.

#### Round-Robin Stream Switching (THE KEY LOGIC)

```verilog
// In SENDEOF, when last line AND last subline:
if ((lineindex[current_stream] == VTOTAL - 1)
    && (sublineindex[current_stream] == FRAMESPERLINE - 1))
begin
  advb_txdata <= EOFTWORD;
  containercount[current_stream] <= containercount[current_stream] + 1;
  sublineindex[current_stream]   <= 0;
  lineindex[current_stream]      <= 0;
  object0[current_stream]        <= 1'b0;   // Next time: start with Object 0
  lastframe[current_stream]      <= 1'b1;
  
  // *** STREAM SWITCH ***
  if (current_stream == NUM_STREAMS - 1)
    current_stream <= {STREAM_IDX_W{1'b0}};  // Wrap to stream 0
  else
    current_stream <= current_stream + 1;     // Next stream
  count <= 0;                                  // Reset blanking counter
end
```
**Why:** This is the **only place** where `current_stream` changes. The switch happens precisely when a complete video frame has been transmitted (all 1085 lines × 3 ADVB frames/line). The wrap-around logic handles any NUM_STREAMS value.

#### Loop Variable for Reset

```verilog
integer s;
// In reset:
for (s = 0; s < NUM_STREAMS; s = s + 1) begin
  containercount[s] <= 32'd0;
  seq_count[s]      <= 16'd0;
  lineindex[s]      <= 16'd0;
  sublineindex[s]   <= 2'd0;
  object0[s]        <= 1'b0;
  lastframe[s]      <= 1'b0;
end
```
**Why:** Every stream's state must be initialized on reset. The loop variable `s` (not `i`, to avoid conflicts) iterates over all streams.

---

### 2. `arinc818_core.v` — Multi-Stream Core

#### New Top-Level Parameter

```verilog
parameter NUM_STREAMS = 2
```
**Why:** Allows the top-level to configure the number of streams, which propagates to all sub-modules.

#### Widened Port Interface

```verilog
output wire [NUM_STREAMS-1:0]    txfifo_wfull,
input  wire [NUM_STREAMS*32-1:0] txfifo_wdata,
input  wire [NUM_STREAMS-1:0]    txfifo_wren,
```
**Why:** Each data source (image generator) needs its own FIFO write interface. The wide buses carry all streams' signals to/from the core.

#### Generate Block for TX FIFOs

```verilog
genvar g;
generate
  for (g = 0; g < NUM_STREAMS; g = g + 1) begin : tx_fifo
    asyncfifo #(.DATASIZE(32), .ADDRSIZE(11)) fifo_inst (
      .wclk  (clk),
      .wrstn (rst_n),
      .winc  (txfifo_wren[g]),              // Stream g's write enable
      .wdata (txfifo_wdata[g*32 +: 32]),    // Stream g's 32-bit data slice
      .wfull (txfifo_wfull[g]),             // Stream g's full flag
      .rclk  (tx_userclk2),
      .rrstn (rst_n),
      .rinc  (txfifo_rden[g]),              // Stream g's read enable from TX
      .rdata (txfifo_rdata[g*32 +: 32]),    // Stream g's read data to TX
      .rempty(txfifo_rempty[g])             // Stream g's empty flag to TX
    );
  end
endgenerate
```
**Why:** `generate for` creates NUM_STREAMS independent FIFO instances at synthesis time. Each FIFO bridges one stream from the system clock domain to the TX clock domain. The `[g*32 +: 32]` part-select operator connects each FIFO to its 32-bit slice of the wide bus.

#### Multi-Stream advbtx Instantiation

```verilog
advbtx #(
  // ...existing parameters...
  .NUM_STREAMS(NUM_STREAMS)        // NEW
) transmit (
  .txfifo_empty  (txfifo_rempty),  // [NUM_STREAMS-1:0] — all streams
  .txfifo_rd     (txfifo_rden),    // [NUM_STREAMS-1:0] — all streams
  .txfifo_rdata  (txfifo_rdata),   // [NUM_STREAMS*32-1:0] — all streams
  .active_stream ()                // Debug (unconnected)
);
```
**Why:** The NUM_STREAMS parameter propagates to advbtx so it creates the correct internal structure. The wide buses carry all streams' FIFO signals.

---

### 3. `arinc818_top.v` — Multi-Stream Top Level

#### Generate Block for Image Generators

```verilog
generate
  for (g = 0; g < NUM_STREAMS; g = g + 1) begin : u_img_gen
    image_pattern_gen #(...) gen_inst (
      .wfull (txfifo_wfull[g]),            // Backpressure from stream g's FIFO
      .wdata (image_wdata[g*32 +: 32]),    // Stream g's pixel data
      .winc  (image_wren[g])               // Stream g's write enable
    );
  end
endgenerate
```
**Why:** Creates one image pattern generator per stream. Each generator independently writes pixels into its own TX FIFO. In a real application, you'd replace these with actual video sources (HDMI capture, camera, etc.).

---

## Timing Diagram

```
Time ──►

Stream 0: [VBLANK][OBJ0][OBJ2 x 3255][EOF_T] ──switch──►
Stream 1:                                       [VBLANK][OBJ0][OBJ2 x 3255][EOF_T] ──switch──►
Stream 0:                                                                            [VBLANK]...
```

Each stream gets exclusive access to the link for one complete video frame (~16.7ms at 60fps). With 2 streams, each stream effectively runs at 30fps on the link. With 4 streams, 15fps each.

---

## Resource Utilization Impact

| Resource | Single-Stream | 2 Streams | 4 Streams |
|----------|:---:|:---:|:---:|
| TX FIFOs (2048×32) | 1 | 2 | 4 |
| Block RAM (36Kb) | ~2 | ~4 | ~8 |
| Per-stream registers | 1 set | 2 sets | 4 sets |
| LUT overhead | Baseline | +~5% | +~10% |
| Image generators | 1 | 2 | 4 |

> [!NOTE]
> The ADVB framing logic (state machine, CRC) is **shared** across all streams — it is NOT duplicated. Only the per-stream state registers and FIFOs are multiplied.

---

## How to Change the Number of Streams

Simply change the `NUM_STREAMS` parameter at the top level:

```verilog
// In arinc818_top.v:
module arinc818_top #(
  parameter NUM_STREAMS = 4    // Change this to any power-of-2 (1, 2, 4, 8...)
)(
```

Everything else scales automatically through the `generate` blocks and parameterized widths.

---

## Verification Checklist

- [ ] Synthesis passes with no errors for NUM_STREAMS=1 (backward compatible)
- [ ] Synthesis passes for NUM_STREAMS=2
- [ ] Simulation shows SOF_I before each stream's Object 0
- [ ] Simulation shows EOF_T at end of each stream's complete frame
- [ ] Frame header Word 1 Source ID matches current_stream value
- [ ] FIFO read-enable only asserts for the active stream's FIFO
- [ ] No data corruption: each stream's payload matches its generator pattern
- [ ] Stream switch occurs exactly at video frame boundaries
