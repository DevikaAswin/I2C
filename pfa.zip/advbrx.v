//=============================================================================
// advbrx.v
//
// ARINC 818 (ADVB) Receiver — Stub Module
//
// This is a placeholder receiver module. It extracts pixel payload data
// from incoming ADVB frames and writes it to the RX FIFO.
//
// For SAM G3 Viewer testing (TX-only to SAM G3), this module is not
// exercised in the primary data path. Replace with full implementation
// when RX path testing is needed.
//=============================================================================

`timescale 1ns / 1ps

module advbrx (
  input             clk,
  input             rst_n,
  input      [31:0] advb_rxdata,
  input      [3:0]  advb_rxcharisk,
  input             rxfifo_wfull,
  output reg [31:0] rxfifo_wdata,
  output reg        rxfifo_wren,
  output reg        crcerror
);

//=========================================================================
// Ordered Set Constants
//=========================================================================
localparam IDLEWORD = 32'hB5B595BC;
localparam SOFIWORD = 32'h5757BFBC;
localparam SOFNWORD = 32'h4F4FB7BC;
localparam EOFNWORD = 32'h4E4E95BC;
localparam EOFTWORD = 32'h4B4B95BC;

//=========================================================================
// State Encoding
//=========================================================================
localparam RX_IDLE    = 3'd0;
localparam RX_HEADER  = 3'd1;
localparam RX_PAYLOAD = 3'd2;
localparam RX_CRC     = 3'd3;
localparam RX_EOF     = 3'd4;

//=========================================================================
// Internal Registers
//=========================================================================
reg [2:0]  rx_state;
reg [9:0]  word_count;
reg [2:0]  hdr_count;
reg        in_payload_frame;  // 1 = this frame carries pixel data

//=========================================================================
// Receiver State Machine
//=========================================================================
always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin
    rx_state         <= RX_IDLE;
    rxfifo_wdata     <= 32'd0;
    rxfifo_wren      <= 1'b0;
    crcerror         <= 1'b0;
    word_count       <= 10'd0;
    hdr_count        <= 3'd0;
    in_payload_frame <= 1'b0;
  end
  else begin
    rxfifo_wren <= 1'b0;  // default: no write
    crcerror    <= 1'b0;  // default: no error

    case (rx_state)
      //-------------------------------------------------------------------
      // RX_IDLE: Wait for SOF
      //-------------------------------------------------------------------
      RX_IDLE: begin
        if (advb_rxcharisk == 4'b0001) begin
          if (advb_rxdata == SOFIWORD) begin
            rx_state         <= RX_HEADER;
            hdr_count        <= 3'd0;
            in_payload_frame <= 1'b0;  // container frame (SOFi)
          end
          else if (advb_rxdata == SOFNWORD) begin
            rx_state         <= RX_HEADER;
            hdr_count        <= 3'd0;
            in_payload_frame <= 1'b1;  // payload frame (SOFn)
          end
        end
      end

      //-------------------------------------------------------------------
      // RX_HEADER: Skip 6-word FC header
      //-------------------------------------------------------------------
      RX_HEADER: begin
        if (hdr_count == 3'd5) begin
          word_count <= 10'd0;
          if (in_payload_frame)
            rx_state <= RX_PAYLOAD;
          else
            rx_state <= RX_PAYLOAD;  // skip container data too
        end
        else begin
          hdr_count <= hdr_count + 3'd1;
        end
      end

      //-------------------------------------------------------------------
      // RX_PAYLOAD: Receive payload data and write to FIFO
      //-------------------------------------------------------------------
      RX_PAYLOAD: begin
        if (advb_rxcharisk == 4'b0000) begin
          // Data word
          if (in_payload_frame && !rxfifo_wfull) begin
            rxfifo_wdata <= advb_rxdata;
            rxfifo_wren  <= 1'b1;
          end
          word_count <= word_count + 10'd1;
        end
        else if (advb_rxcharisk == 4'b0001) begin
          // K-character detected — likely EOF
          if (advb_rxdata == EOFNWORD || advb_rxdata == EOFTWORD)
            rx_state <= RX_IDLE;
        end
      end

      default: rx_state <= RX_IDLE;
    endcase
  end
end

endmodule
