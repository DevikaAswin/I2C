//=============================================================================
// image_pattern_gen.v
//
// ARINC 818 Image Pattern Generator — 1920×1080 @ 60Hz for SAM G3 Viewer
//
// Generates an 8 vertical color-bar test image at 1920×1080 resolution
// with 3 bytes/pixel (RGB24). Packs pixels into 32-bit words and writes
// them into the async FIFO write port.
//
// Color Bars (left to right, each 240 pixels wide):
//   Bar 0 = White   (FF,FF,FF)    Bar 4 = Magenta (FF,00,FF)
//   Bar 1 = Yellow  (FF,FF,00)    Bar 5 = Red     (FF,00,00)
//   Bar 2 = Cyan    (00,FF,FF)    Bar 6 = Blue    (00,00,FF)
//   Bar 3 = Green   (00,FF,00)    Bar 7 = Black   (00,00,00)
//
// Pixel Packing (RGB24 -> 32-bit words):
//   Every 4 pixels (12 bytes) pack into 3 words:
//     Word 0: {R0, G0, B0, R1}
//     Word 1: {G1, B1, R2, G2}
//     Word 2: {B2, R3, G3, B3}
//
//   1920 pixels/line -> 1440 words/line (480 groups of 3 words)
//
// SAM G3 Viewer Specs:
//   - Link Rate:     4× (4.25 Gbps)
//   - Frame Rate:    60 Hz
//   - H Active:      1920
//   - V Active:      1080
//   - Total Lines:   1085
//   - ADVB Frames/Line: 3
//   - Payload Bytes/Frame: 1920
//=============================================================================

`timescale 1ns / 1ps

module image_pattern_gen #(
  parameter HACTIVE       = 1920,
  parameter VACTIVE       = 1080,
  parameter BytesPerPixel = 3
)(
  input             clk,         // write-side clock
  input             rst_n,       // active-low reset
  input             wfull,       // FIFO full flag (backpressure)
  output reg [31:0] wdata,       // 32-bit data output to FIFO
  output reg        winc,        // write enable to FIFO
  output reg        frame_sync   // pulse high for 1 cycle at start of each frame
);

  //=========================================================================
  // Local Parameters
  //=========================================================================
  localparam BYTES_PER_LINE   = HACTIVE * BytesPerPixel;      // 5760
  localparam WORDS_PER_LINE   = BYTES_PER_LINE / 4;           // 1440
  localparam PIXELS_PER_GROUP = 4;                             // 4 pixels per packing group
  localparam WORDS_PER_GROUP  = 3;                             // 3 words per packing group
  localparam GROUPS_PER_LINE  = HACTIVE / PIXELS_PER_GROUP;   // 480 groups per line
  localparam BAR_WIDTH        = HACTIVE / 8;                   // 240 pixels per bar

  //=========================================================================
  // State Machine States
  //=========================================================================
  localparam S_IDLE      = 3'd0;
  localparam S_LOAD      = 3'd1;  // latch pixel colors for a group of 4
  localparam S_PACK0     = 3'd2;  // output word 0: {R0, G0, B0, R1}
  localparam S_PACK1     = 3'd3;  // output word 1: {G1, B1, R2, G2}
  localparam S_PACK2     = 3'd4;  // output word 2: {B2, R3, G3, B3}
  localparam S_LINE_DONE = 3'd5;  // line complete, advance

  //=========================================================================
  // Internal Registers
  //=========================================================================
  reg [2:0]  gen_state;
  reg [10:0] group_base;        // base pixel X for current group (0, 4, 8, ... max 1916)
  reg [10:0] line_y;            // current video line (0 to VACTIVE-1 = 1079)
  reg [8:0]  group_count;       // number of groups completed this line (0 to 479)

  // Latched pixel colors for 4 pixels in current group
  reg [7:0] p0_r, p0_g, p0_b;
  reg [7:0] p1_r, p1_g, p1_b;
  reg [7:0] p2_r, p2_g, p2_b;
  reg [7:0] p3_r, p3_g, p3_b;

  //=========================================================================
  // Color Bar Lookup Function
  //
  // BAR_WIDTH = 240 pixels. Since 240 is NOT a power of 2, we use
  // comparators instead of bit-extraction.
  //
  // Bar 0: x in [   0,  239]  -> White
  // Bar 1: x in [ 240,  479]  -> Yellow
  // Bar 2: x in [ 480,  719]  -> Cyan
  // Bar 3: x in [ 720,  959]  -> Green
  // Bar 4: x in [ 960, 1199]  -> Magenta
  // Bar 5: x in [1200, 1439]  -> Red
  // Bar 6: x in [1440, 1679]  -> Blue
  // Bar 7: x in [1680, 1919]  -> Black
  //=========================================================================
  function [23:0] get_bar_color;
    input [10:0] x_pos;
    begin
      if      (x_pos < 11'd240)  get_bar_color = 24'hFFFFFF; // White
      else if (x_pos < 11'd480)  get_bar_color = 24'hFFFF00; // Yellow
      else if (x_pos < 11'd720)  get_bar_color = 24'h00FFFF; // Cyan
      else if (x_pos < 11'd960)  get_bar_color = 24'h00FF00; // Green
      else if (x_pos < 11'd1200) get_bar_color = 24'hFF00FF; // Magenta
      else if (x_pos < 11'd1440) get_bar_color = 24'hFF0000; // Red
      else if (x_pos < 11'd1680) get_bar_color = 24'h0000FF; // Blue
      else                       get_bar_color = 24'h000000; // Black
    end
  endfunction

  //=========================================================================
  // Combinational color lookups for the current group of 4 pixels
  //=========================================================================
  wire [23:0] color_p0 = get_bar_color(group_base);
  wire [23:0] color_p1 = get_bar_color(group_base + 11'd1);
  wire [23:0] color_p2 = get_bar_color(group_base + 11'd2);
  wire [23:0] color_p3 = get_bar_color(group_base + 11'd3);

  //=========================================================================
  // Main State Machine
  //=========================================================================
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      gen_state   <= S_IDLE;
      group_base  <= 11'd0;
      line_y      <= 11'd0;
      group_count <= 9'd0;
      wdata       <= 32'd0;
      winc        <= 1'b0;
      frame_sync  <= 1'b0;
      p0_r <= 8'd0; p0_g <= 8'd0; p0_b <= 8'd0;
      p1_r <= 8'd0; p1_g <= 8'd0; p1_b <= 8'd0;
      p2_r <= 8'd0; p2_g <= 8'd0; p2_b <= 8'd0;
      p3_r <= 8'd0; p3_g <= 8'd0; p3_b <= 8'd0;
    end
    else begin
      // Defaults: de-assert single-cycle pulses
      winc       <= 1'b0;
      frame_sync <= 1'b0;

      case (gen_state)
        //-------------------------------------------------------------------
        // S_IDLE: Reset per-line state, emit frame_sync for line 0
        //-------------------------------------------------------------------
        S_IDLE: begin
          group_base  <= 11'd0;
          group_count <= 9'd0;

          if (line_y == 11'd0)
            frame_sync <= 1'b1;   // pulse at start of new video frame

          gen_state <= S_LOAD;
        end

        //-------------------------------------------------------------------
        // S_LOAD: Latch RGB values for 4 consecutive pixels
        //-------------------------------------------------------------------
        S_LOAD: begin
          p0_r <= color_p0[23:16]; p0_g <= color_p0[15:8]; p0_b <= color_p0[7:0];
          p1_r <= color_p1[23:16]; p1_g <= color_p1[15:8]; p1_b <= color_p1[7:0];
          p2_r <= color_p2[23:16]; p2_g <= color_p2[15:8]; p2_b <= color_p2[7:0];
          p3_r <= color_p3[23:16]; p3_g <= color_p3[15:8]; p3_b <= color_p3[7:0];
          gen_state <= S_PACK0;
        end

        //-------------------------------------------------------------------
        // S_PACK0: Output Word 0 = {R0, G0, B0, R1}
        //-------------------------------------------------------------------
        S_PACK0: begin
          if (wfull) begin
            winc <= 1'b0;          // stall - FIFO full
          end
          else begin
            wdata <= {p0_r, p0_g, p0_b, p1_r};
            winc  <= 1'b1;
            gen_state <= S_PACK1;
          end
        end

        //-------------------------------------------------------------------
        // S_PACK1: Output Word 1 = {G1, B1, R2, G2}
        //-------------------------------------------------------------------
        S_PACK1: begin
          if (wfull) begin
            winc <= 1'b0;          // stall - FIFO full
          end
          else begin
            wdata <= {p1_g, p1_b, p2_r, p2_g};
            winc  <= 1'b1;
            gen_state <= S_PACK2;
          end
        end

        //-------------------------------------------------------------------
        // S_PACK2: Output Word 2 = {B2, R3, G3, B3}
        //         Then advance to next group or finish line
        //-------------------------------------------------------------------
        S_PACK2: begin
          if (wfull) begin
            winc <= 1'b0;          // stall - FIFO full
          end
          else begin
            wdata       <= {p2_b, p3_r, p3_g, p3_b};
            winc        <= 1'b1;
            group_count <= group_count + 9'd1;

            if ((group_count + 9'd1) >= GROUPS_PER_LINE) begin
              // All 480 groups done -> 1440 words output -> line complete
              gen_state <= S_LINE_DONE;
            end
            else begin
              // More groups remain - advance to next 4 pixels
              group_base <= group_base + 11'd4;
              gen_state  <= S_LOAD;
            end
          end
        end

        //-------------------------------------------------------------------
        // S_LINE_DONE: Advance to next line or wrap to next frame
        //-------------------------------------------------------------------
        S_LINE_DONE: begin
          group_base  <= 11'd0;
          group_count <= 9'd0;

          if (line_y == (VACTIVE - 1))
            line_y <= 11'd0;       // end of frame -> wrap to line 0
          else
            line_y <= line_y + 11'd1;

          gen_state <= S_IDLE;
        end

        default: begin
          gen_state <= S_IDLE;
        end
      endcase
    end
  end

endmodule
