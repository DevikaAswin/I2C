//=============================================================================
// tb_arinc818_multistream.v — Testbench for Multi-Stream ARINC 818 TX
//
// Verifies that:
//   1. Multiple streams' FIFOs are written independently
//   2. The transmitter sends complete video frames per stream
//   3. Stream switching occurs after EOF_T (round-robin)
//   4. Frame headers carry the correct stream ID in Source ID field
//   5. ADVB framing protocol (SOF/HDR/CONT/ANC/PAYLOAD/CRC/EOF) is intact
//
// Architecture:
//   - 2 simple data generators write incrementing patterns into 2 FIFOs
//   - arinc818_core (NUM_STREAMS=2) reads FIFOs and generates ADVB frames
//   - A monitor task watches advb_txdata output and reports frame events
//=============================================================================

`timescale 1ns / 1ps

module tb_arinc818_multistream;

  //=========================================================================
  // Parameters
  //=========================================================================
  localparam NUM_STREAMS = 2;
  localparam CLK_PERIOD_SYS = 9.4;    // ~106.25 MHz system clock
  localparam CLK_PERIOD_TX  = 9.4;    // ~106.25 MHz TX user clock (same for sim)
  localparam CLK_PERIOD_RX  = 9.4;    // ~106.25 MHz RX user clock

  //=========================================================================
  // Ordered Set Constants (for monitor)
  //=========================================================================
  localparam IDLEWORD = 32'hB5B595BC;
  localparam SOFIWORD = 32'h5757BFBC;
  localparam SOFNWORD = 32'h4F4FB7BC;
  localparam EOFNWORD = 32'h4E4E95BC;
  localparam EOFTWORD = 32'h4B4B95BC;

  //=========================================================================
  // Clock & Reset
  //=========================================================================
  reg clk_sys    = 0;
  reg clk_tx     = 0;
  reg clk_rx     = 0;
  reg rst_n      = 0;

  always #(CLK_PERIOD_SYS/2) clk_sys = ~clk_sys;
  always #(CLK_PERIOD_TX/2)  clk_tx  = ~clk_tx;
  always #(CLK_PERIOD_RX/2)  clk_rx  = ~clk_rx;

  //=========================================================================
  // Per-Stream Data Source Signals
  //=========================================================================
  wire [NUM_STREAMS-1:0]      txfifo_wfull;
  reg  [NUM_STREAMS*32-1:0]   txfifo_wdata;
  reg  [NUM_STREAMS-1:0]      txfifo_wren;

  //=========================================================================
  // ADVB Link Output
  //=========================================================================
  wire [31:0] advb_txdata;
  wire [3:0]  advb_txcharisk;

  //=========================================================================
  // RX Side (loopback for completeness)
  //=========================================================================
  wire        rxfifo_rempty;
  reg         rxfifo_rden;
  wire [31:0] rxfifo_rdata;

  //=========================================================================
  // DUT: Multi-Stream arinc818_core
  //=========================================================================
  arinc818_core #(
    .NUM_STREAMS(NUM_STREAMS)
  ) dut (
    .clk           (clk_sys),
    .tx_userclk2   (clk_tx),
    .rx_userclk2   (clk_rx),
    .rst_n         (rst_n),
    .txfifo_wfull  (txfifo_wfull),
    .txfifo_wdata  (txfifo_wdata),
    .txfifo_wren   (txfifo_wren),
    .advb_txdata   (advb_txdata),
    .advb_txcharisk(advb_txcharisk),
    .advb_rxdata   (advb_txdata),       // Loopback: TX→RX
    .advb_rxcharisk(advb_txcharisk),    // Loopback: TX→RX
    .rxfifo_rempty (rxfifo_rempty),
    .rxfifo_rden   (rxfifo_rden),
    .rxfifo_rdata  (rxfifo_rdata)
  );

  //=========================================================================
  // Stream Data Generators
  //
  // Each stream writes a simple incrementing pattern into its FIFO
  // whenever the FIFO is not full. Stream 0 writes 0x0000_0000,
  // 0x0000_0001, ... and Stream 1 writes 0x8000_0000, 0x8000_0001, ...
  // The MSB difference makes it easy to identify which stream's data
  // appears in the payload.
  //=========================================================================
  reg [31:0] stream_counter [0:NUM_STREAMS-1];
  integer i;

  always @(posedge clk_sys or negedge rst_n) begin
    if (!rst_n) begin
      for (i = 0; i < NUM_STREAMS; i = i + 1) begin
        stream_counter[i] <= {i[0], 31'd0};   // Stream 0: 0x00000000, Stream 1: 0x80000000
        txfifo_wren[i]    <= 1'b0;
        txfifo_wdata[i*32 +: 32] <= 32'd0;
      end
    end
    else begin
      for (i = 0; i < NUM_STREAMS; i = i + 1) begin
        if (!txfifo_wfull[i]) begin
          txfifo_wren[i]           <= 1'b1;
          txfifo_wdata[i*32 +: 32] <= stream_counter[i];
          stream_counter[i]        <= stream_counter[i] + 1;
        end
        else begin
          txfifo_wren[i] <= 1'b0;
        end
      end
    end
  end

  //=========================================================================
  // RX FIFO Consumer (always read when available)
  //=========================================================================
  always @(posedge clk_sys) begin
    rxfifo_rden <= ~rxfifo_rempty;
  end

  //=========================================================================
  // ADVB Output Monitor
  //
  // Watches advb_txdata and reports when SOF/EOF frames are detected.
  // This helps verify that stream switching is working correctly.
  //=========================================================================
  integer sof_count  = 0;
  integer eof_count  = 0;
  integer eoft_count = 0;

  always @(posedge clk_tx) begin
    if (rst_n) begin
      case (advb_txdata)
        SOFIWORD: begin
          sof_count <= sof_count + 1;
          $display("[%0t] SOF_I detected (Container Frame) — SOF #%0d", $time, sof_count);
        end
        SOFNWORD: begin
          sof_count <= sof_count + 1;
          // Only print first few to avoid flooding console
          if (sof_count < 20)
            $display("[%0t] SOF_N detected (Payload Frame)   — SOF #%0d", $time, sof_count);
        end
        EOFNWORD: begin
          eof_count <= eof_count + 1;
        end
        EOFTWORD: begin
          eoft_count <= eoft_count + 1;
          $display("[%0t] *** EOF_T detected — Stream switch! *** (EOF_T #%0d)", $time, eoft_count);
        end
      endcase
    end
  end

  //=========================================================================
  // Simulation Control
  //=========================================================================
  initial begin
    $dumpfile("tb_arinc818_multistream.vcd");
    $dumpvars(0, tb_arinc818_multistream);

    $display("=============================================================");
    $display("  ARINC 818 Multi-Stream Transmitter Testbench");
    $display("  NUM_STREAMS = %0d", NUM_STREAMS);
    $display("=============================================================");

    // Hold reset for 100ns
    rst_n = 0;
    #100;
    rst_n = 1;
    $display("[%0t] Reset released", $time);

    // Run simulation for enough time to see at least one full video frame
    // per stream. A full frame is ~1085 lines × 3 frames/line = ~3255 ADVB
    // frames plus overhead. At 106 MHz, each ADVB frame is ~490 clocks.
    // Total ~ 3255 × 490 × 2 streams ≈ 3.2M clocks ≈ 30ms.
    //
    // For quick verification, run 5ms to see the beginning of the pattern:
    #5_000_000;

    $display("=============================================================");
    $display("  Simulation Complete");
    $display("  Total SOF frames:  %0d", sof_count);
    $display("  Total EOF_N:       %0d", eof_count);
    $display("  Total EOF_T:       %0d (stream switches)", eoft_count);
    $display("=============================================================");

    $finish;
  end

endmodule
