module arinc818_top
#(
  // MULTISTREAM (new): video streams multiplexed on the one SFP link.
  // 1 = your original single-stream design, bit-for-bit. Max 8.
  // Stream IDs and RX_FANOUT are set in arinc818_core.
  parameter NUM_STREAMS = 2
)
(
  input  wire sysclk_p,
  input  wire sysclk_n,
  input  wire mgtrefclk_p,
  input  wire mgtrefclk_n,
//  input  wire rst_n,
  input  wire sfp_rx_n,
  input  wire sfp_rx_p,
  output wire sfp_tx_n,
  output wire sfp_tx_p,
  output wire sfp_tx_disable,
  input  wire cpu_reset,
  output wire cplllock_out,
  output wire led1,
  input wire         tx_rst,
    input wire       rx_rst

);

wire        drp_clk25M;
wire        mgt_clk250M;
wire        clk_127M5;
wire        tx_userclk2;
wire        rx_userclk2;
wire        txfifo_wfull;
wire [31:0] image_wdata;
wire        image_wren;
wire [31:0] advb_txdata;
wire [3:0]  advb_txcharisk;
wire [31:0] advb_rxdata;
wire [3:0]  advb_rxcharisk;
wire        rxfifo_rempty;
wire        image_rden;
reg  image_rden1;

wire [31:0] image_rdata;
wire        locked;
wire [1:0]  txbufstatus_out;
wire        rst_n;
wire        reset_tx_done;
wire        reset_rx_done;


assign rst_n = locked & !cpu_reset;
assign sfp_tx_disable = 1'b1;



clk_wiz_0 pll
(
  .clk_out1 (mgt_clk250M),     // output clk_out1
  .clk_out2 (drp_clk25M),     // output clk_out2
  .clk_out3 (clk_127M5),     // output clk_out3
  .locked   (locked),       // output locked
  .clk_in1_p(sysclk_p),    // input clk_in1_p
  .clk_in1_n(sysclk_n)
);


arinc818_core #(
  .NUM_STREAMS   (NUM_STREAMS)           // MULTISTREAM
) trasmit_receive
(
  .clk           (clk_127M5),
  .tx_userclk2   (tx_userclk2),
  .rx_userclk2   (rx_userclk2),
  .rst_n         (rst_n),
  .txfifo_wfull  (txfifo_wfull),
  .txfifo_wdata  (image_rdata),
  .txfifo_wren   (image_rden1),
  .advb_txdata   (advb_txdata),
  .advb_txcharisk(advb_txcharisk),
  .advb_rxdata   (advb_rxdata),// it is transceiver data
  .advb_rxcharisk(advb_rxcharisk),
  .rxfifo_rempty (rxfifo_rempty),
  .rxfifo_rden   (image_rden),
  .rxfifo_rdata  (image_rdata),
  .reset_tx_done (!tx_rst ),
  .reset_rx_done (!rx_rst )
);


always @(posedge clk_127M5 or negedge rst_n) begin
  if (!rst_n) begin
    image_rden1 <=0;
    end
   else begin
   image_rden1       <=  image_rden;

  end
  end
arinc818_trans_top transceiver_inst
(
  .mgtrefclk0_x0y2_p    (mgtrefclk_p),
  .mgtrefclk0_x0y2_n    (mgtrefclk_n),
  .ch0_gthrxn_in        (sfp_rx_n),
  .ch0_gthrxp_in        (sfp_rx_p),
  .ch0_gthtxn_out       (sfp_tx_n),
  .ch0_gthtxp_out       (sfp_tx_p),
  .reset_clk_freerun_in (drp_clk25M),
  .reset_all_in         (!rst_n),
  .userclk_tx_usrclk2   (tx_userclk2),
  .userclk_rx_usrclk2   (rx_userclk2),
  .advb_txdata          (advb_txdata),
  .advb_txcharisk       (advb_txcharisk),
  .advb_rxdata          (advb_rxdata),
  .advb_rxcharisk       (advb_rxcharisk),
  .cplllock_out         (cplllock_out),
  .reset_tx_done        (reset_tx_done),
  .reset_rx_done        (reset_rx_done)
);

assign image_rden = rxfifo_rempty ? 1'b0 : 1'b1;
assign led1       = (image_rdata == 32'hA5) ? 1'b0: 1'b1;

endmodule
