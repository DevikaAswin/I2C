# ARINC 818 multistream: changed code and full explanation

**Folder:** `ARINC818_MULTISTREAM_FINAL`

| File | Status |
|---|---|
| `arinc818_top.v` | changed (one new parameter) |
| `arinc818_core.v` | changed (per-stream FIFOs and receivers) |
| `advbtx.v` | changed (stream switching inside your existing FSM) |
| `stream_select.v` | **new** file (receive-side stream filter) |

**Not in this folder because they are not changed at all:** `asyncfifo.v`, `advbrx.v`, `sync.v`, `rxdata_formater.v`, `arinc818_trans_top` and `clk_wiz_0`. Keep using your existing copies.

To use the code in Vivado:

1. Replace your `arinc818_top.v`, `arinc818_core.v` and `advbtx.v` with the files in this folder.
2. Add `stream_select.v` to the project.

---

## 1. What "multistream" means in ARINC 818

The extract from the spec:

> "As an option, the capability to multiplex multiple video streams onto a single high-speed link may be provided through assignment of a unique Source ID or Destination ID parameter for each video stream. Line synchronous timing may be maintained by offsetting the timing of synchronized video streams by fixed fraction of line time to minimize DU line buffer size."

It contains three requirements:

1. **Several video streams share one link** (one SFP and one GTH lane).
2. **Each stream has a unique Source ID (S_ID) or Destination ID (D_ID).** These are in the FC frame header: D_ID is in word 0 (`{R_CTL, D_ID}`) and S_ID is in word 1 (`{CS_CTL, S_ID}`). The receiver (the Display Unit, DU) uses them to tell the streams apart.
3. **Line-synchronous timing.** The streams are sent line by line, interleaved, and each stream is shifted by a fixed fraction of a line time. The DU then needs only a small line buffer per stream, instead of a full frame buffer.

The design does exactly this:

- Every stream is a complete, normal ADVB sequence. It has its own Object 0 frame (container header and ancillary data), its own SEQ_CNT, and its own EOFt with END_SEQ on its last frame.
- Every video line is sent once per stream, in equal time slots. Stream k starts its line exactly **k / NUM_STREAMS** of a line time after stream 0.

---

## 2. What the link looks like

Example: `NUM_STREAMS = 2`, your 1280x1024 with 2 FC frames per line. The numbers between the frames are idle words, all taken from your existing `select_idles` table.

```
idle PRE
Obj0  stream0  (SOFi, S_ID 000001, SEQ_CNT 0)
idle 6                                            <- INTER_OBJ2_IDLE
Obj0  stream1  (SOFi, S_ID 000002, SEQ_CNT 0)
idle POST                                         <- POST_OBJ0_IDLE

line 0  stream0 frame0 (SOFn, S_ID 000001, SEQ_CNT 1)
idle 6
line 0  stream0 frame1 (SOFn, S_ID 000001, SEQ_CNT 2)
idle EOL                                          <- END_LINE_IDLE
line 0  stream1 frame0 (SOFn, S_ID 000002, SEQ_CNT 1)
idle 6
line 0  stream1 frame1 (SOFn, S_ID 000002, SEQ_CNT 2)
idle EOL

line 1  stream0 frame0 (SEQ_CNT 3)  6  frame1 (SEQ_CNT 4)  EOL
line 1  stream1 frame0 (SEQ_CNT 3)  6  frame1 (SEQ_CNT 4)  EOL
...
line 1023 stream0 frame0 (SEQ_CNT 2047)  6  frame1 (SEQ_CNT 2048, END_SEQ, EOFt)  EOL
line 1023 stream1 frame0 (SEQ_CNT 2047)  6  frame1 (SEQ_CNT 2048, END_SEQ, EOFt)
idle PRE
next video frame: Obj0 stream0 ...
```

Points to notice:

- **Each stream's slot inside a line is identical:** its FC frames, the inter-frame idles, then `END_LINE_IDLE`. That is why the offset between streams is a fixed fraction (1/N) of the line time.
- **SEQ_ID is the same for all streams in one video frame** (`containercount[7:0]`). This is allowed, because sequences from different sources are told apart by S_ID.
- **SEQ_CNT counts separately per stream.** Both streams count 0, 1, 2, ... 2048.
- **Each stream's last frame carries END_SEQ (F_CTL = 380000) and EOFt.**
- **With `NUM_STREAMS = 1`, this reduces exactly to your original timeline.**

---

## 3. Block diagram

### Transmit side (`advbtx`)

```
  FIFO stream0 --+
  FIFO stream1 --+--> [ select current stream ] --> your original FSM --> GTH TX
  FIFO stream2 --+        (register 'stream')        (header uses stream's S_ID/D_ID)
```

### Receive side, `RX_FANOUT = 1` (incoming link is a normal single-stream source)

```
GTH RX -> rxdata_formater -> sync -> advbrx (your original, unchanged) --+--> FIFO stream0
                                                                         +--> FIFO stream1
                                                                         +--> FIFO stream2 ...
```

The same received video is copied into every stream FIFO, so the TX sends N copies, each with its own ID. Use this to test multistream TX with the single-stream source you already have.

### Receive side, `RX_FANOUT = 0` (incoming link already carries N streams)

```
                               +-> stream_select(ID0) -> advbrx -> FIFO stream0
GTH RX -> rxdata_formater -> sync -+-> stream_select(ID1) -> advbrx -> FIFO stream1
                               +-> stream_select(ID2) -> advbrx -> FIFO stream2 ...
```

Each `stream_select` keeps only the frames of its own stream and replaces all other frames with idle words. The `advbrx` behind it therefore sees an ordinary single-stream link, so **your `advbrx` is reused without any change**.

---

## 4. `arinc818_top.v`: what changed

Only two things changed.

**(a) A new parameter:**

```verilog
module arinc818_top
#(
  parameter NUM_STREAMS = 2
)
(
  ... all ports exactly as before ...
```

- `NUM_STREAMS = 1` gives your original design.
- `NUM_STREAMS = 2` to `8` gives multistream.

**(b) The parameter is passed to the core:**

```verilog
arinc818_core #(
  .NUM_STREAMS   (NUM_STREAMS)
) trasmit_receive
(
  ... port connections exactly as before ...
);
```

Everything else in the top (clocking, reset, `image_rden1`, transceiver instance, `led1`) is unchanged.

---

## 5. `arinc818_core.v`: what changed

### 5.1 New parameter

```verilog
module arinc818_core
#(
  parameter NUM_STREAMS = 1
)
```

### 5.2 The multistream settings (the only things you edit)

```verilog
localparam [191:0] STREAM_SRC_ID  = {24'h000008, 24'h000007, 24'h000006, 24'h000005,
                                     24'h000004, 24'h000003, 24'h000002, 24'h000001};
localparam [191:0] STREAM_DEST_ID = {8{24'h007912}};
localparam RX_FANOUT = 1;
```

**The ID tables:**

- They are 8 entries of 24 bits. Stream k uses bits `[24*k +: 24]`, so the **rightmost entry is stream 0**.
- Stream 0 = D_ID `007912` and S_ID `000001`, the same IDs as your original design.
- Streams 1 to 7 have S_ID `000002` to `000008` and the same D_ID.
- You can instead give each stream a different D_ID and keep one S_ID. The spec allows either; just keep every stream different in at least one of the two.
- **The same table is used by the TX (to stamp the frames) and by the RX (to pick the frames out).** There is only one place to edit, so TX and RX cannot disagree.

**`RX_FANOUT`:** see the block diagram in section 3.

- `1` (default): the incoming link is single-stream and is copied into all stream FIFOs.
- `0`: the incoming link carries N streams and is separated by ID.

A helper derived from these settings:

```verilog
localparam RX_DEMUX = (NUM_STREAMS > 1) && (RX_FANOUT == 0);
```

### 5.3 Stream 0 keeps your original instances and names

```verilog
asyncfifo #(.DATASIZE(32), .ADDRSIZE(11)) tx_fifo ( ... exactly as before ... );

assign txfifo_rden            = txfifo_rden_all[0];
assign txfifo_rempty_all[0]   = txfifo_rempty;
assign txfifo_rdata_all[31:0] = txfifo_rdata;
```

- `tx_fifo` is your FIFO with the same connections. Its three read-side signals are put into the all-stream buses as stream 0.
- The instance names `tx_fifo`, `transmit`, `align`, `receive` and `synctop` are all kept, so **your ILA probes and XDC constraints still find the same paths**.

### 5.4 The transmitter instance

```verilog
advbtx #(
  .HACTIVE          (1280),
  .VACTIVE          (1024),
  .BytesPerPixel    (3),
  .FRAMERATE        (60),
  .NUM_STREAMS      (NUM_STREAMS),
  .STREAM_SRC_ID    (STREAM_SRC_ID),
  .STREAM_DEST_ID   (STREAM_DEST_ID)
) transmit
(
  .clk               (tx_userclk2),
  .rst_n             ( reset_tx_done),
  .advb_txdata       (advb_txdata),
  .advb_txcharisk    (advb_txcharisk),
  .txfifo_rempty_all (txfifo_rempty_all),
  .txfifo_rden_all   (txfifo_rden_all),
  .txfifo_rdata_all  (txfifo_rdata_all)
);
```

- The resolution and frame-rate values are unchanged from yours.
- The FIFO ports are now buses:
  - `txfifo_rempty_all[k]` is stream k's empty flag.
  - `txfifo_rden_all[k]` is stream k's read enable.
  - `txfifo_rdata_all[32*k +: 32]` is stream k's data.

### 5.5 What stream 0's `advbrx` receives

```verilog
generate
  if (RX_DEMUX) begin : g_sel0
    stream_select #(.MATCH_DID(STREAM_DEST_ID[23:0]), .MATCH_SID(STREAM_SRC_ID[23:0])) sel ( ... );
  end
  else begin : g_nosel0
    assign rx0_data    = advb_rxdata_sync;
    assign rx0_charisk = advb_rxcharisk_sync;
  end
endgenerate
```

- In single-stream or fanout mode, `advbrx` gets `sync`'s output directly, **exactly as before**.
- In demux mode it gets the filtered output instead.

Only these two connections of your `receive` instance changed:

```verilog
.advb_data(rx0_data),                    // was advb_rxdata_sync
.advb_rxcharisk(rx0_charisk),            // was advb_rxcharisk_sync
```

### 5.6 Streams 1 to N-1 (generate loop)

```verilog
for (s = 1; s < NUM_STREAMS; s = s + 1) begin : g_stream
  if (RX_DEMUX) begin : g_rx
     stream_select (this stream's IDs) -> advbrx (unchanged copy)
     fifo_wdata/fifo_wren = that advbrx's rxfifo_wdata/rxfifo_wren
  end
  else begin : g_fanout
     fifo_wdata/fifo_wren = stream 0's rxfifo_wdata/rxfifo_wren
  end
  asyncfifo tx_fifo (same settings as stream 0: ADDRSIZE 11, wclk rx_userclk2, rclk tx_userclk2)
end
```

Each extra stream's FIFO uses the same parameters, clocks and resets as your stream 0 FIFO.

Instance names in Vivado:

- `g_stream[1].tx_fifo`, `g_stream[2].tx_fifo`, ...
- in demux mode also `g_stream[k].g_rx.sel` and `g_stream[k].g_rx.receive`.

`rxfifo_wfull` on the extra `advbrx` copies is left unconnected, the same as in your stream 0 instance today.

---

## 6. `advbtx.v`: what changed (the main part)

**Design rule followed:** your FSM, header functions, CRC, running disparity, ordered sets and byte swap are untouched. Only these changed:

- the port list,
- frame header words 0 and 1,
- the reset values of two new registers,
- the decisions inside `SENDEOF`.

### 6.1 New parameters

```verilog
parameter NUM_STREAMS = 1,
parameter [191:0] STREAM_SRC_ID  = { ... 24'h000002, 24'h000001},
parameter [191:0] STREAM_DEST_ID = {8{24'h007912}}
```

The defaults equal your original IDs for stream 0.

### 6.2 New ports (one per stream)

```verilog
input      [NUM_STREAMS-1:0]    txfifo_rempty_all,
output     [NUM_STREAMS-1:0]    txfifo_rden_all,
input      [32*NUM_STREAMS-1:0] txfifo_rdata_all
```

These replace the old `txfifo_rempty`, `txfifo_rden` and `txfifo_rdata` ports.

### 6.3 The stream selector: why your FSM did not need to change

```verilog
reg  [2:0]  stream;          // which stream the FSM is sending now
reg  [15:0] seq_line_base;   // SEQ_CNT at the start of the current line slot
reg         txfifo_rden;
wire        txfifo_rempty = txfifo_rempty_all[stream];
(* DONT_TOUCH = "TRUE", MARK_DEBUG = "TRUE" *)
wire [31:0] txfifo_rdata  = txfifo_rdata_all[32*stream +: 32];
wire [23:0] cur_dest_id   = STREAM_DEST_ID[24*stream +: 24];
wire [23:0] cur_src_id    = STREAM_SRC_ID [24*stream +: 24];

for (g = 0; g < NUM_STREAMS; g = g + 1)
  assign txfifo_rden_all[g] = txfifo_rden & (stream == g);
```

How it works:

- The signals `txfifo_rempty`, `txfifo_rden` and `txfifo_rdata` still exist inside the module with the **same names**. They are now connected to the FIFO of the **current** stream. So every line of your FSM that used them (IDLE waiting on `!txfifo_rempty`, SENDHDR and SENDPAYLOAD driving `txfifo_rden`, SENDPAYLOAD using `txfifo_rdata`) works unchanged.
- `txfifo_rden` is sent only to the current stream's FIFO. The other FIFOs are not read.
- `stream` changes only in `SENDEOF`. By then `txfifo_rden` is already 0, because your SENDPAYLOAD clears it on the last payload word, so a read can never go to the wrong FIFO.
- Your `MARK_DEBUG` attribute is now on the internal `txfifo_rdata`, so the ILA probe keeps the same name.

### 6.4 Frame header words 0 and 1

```verilog
0 : frameheader = {R_CTL, cur_dest_id};   // was {R_CTL, DEST_ID}
1 : frameheader = {8'h00, cur_src_id};    // was {8'h00, SRC_ID}
```

Your SENDHDR sends `frameheader(frame_hdrcnt)` **and** feeds the same value into `nextcrc32`, so the CRC automatically covers the per-stream IDs.

### 6.5 Reset values of the new registers

```verilog
stream           <= 3'd0;
seq_line_base    <= 16'h0;
```

### 6.6 `SENDEOF`: choosing what comes next

Your original `SENDEOF` had three branches. All the idle-word values, EOF disparity choices (`next_rd`) and counters are kept. Only "who goes next" was added.

**Branch A: an Object 0 frame just ended** (`object0 == 0`)

```verilog
seq_line_base <= 16'h0;
if (stream == (NUM_STREAMS - 1)) begin   // last stream's Object 0 done
  stream      <= 3'd0;
  object0     <= 1'b1;                   // now start the video lines
  idle_target <= POST_OBJ0_IDLE;
end
else begin                               // more streams still need their Object 0
  stream      <= stream + 1'b1;
  object0     <= 1'b0;                   // next frame is again an Object 0 (SOFi)
  idle_target <= INTER_OBJ2_IDLE;
end
// EOFn, chosen by next_rd as before
```

- Because `object0` stays 0 for the next stream, your SENDSOF sends **SOFi** and sets SEQ_CNT to 0, and your SENDHDR goes to SENDCONT/SENDANC. Each stream therefore gets a complete, normal Object 0 frame.
- For `NUM_STREAMS = 1`, `stream == 0 == NUM_STREAMS-1` is always true, so this is exactly your original branch.

**Branch B: the last FC frame of a line just ended** (`frame_in_line == FRAMESPERLINE-1`). This branch now has three cases.

*Case B1: not the last stream yet.* The next stream sends the **same** line:

```verilog
stream      <= stream + 1'b1;
idle_target <= END_LINE_IDLE;            // equal slot per stream
seq_count   <= seq_line_base;            // next stream restarts SEQ_CNT from the same base
lineindex   <= lineindex;                // same line
// EOFt if this was line VACTIVE-1 (this stream's last frame), else EOFn
```

*Case B2: last stream, last line.* This is the end of the video frame. Your original code, plus:

```verilog
stream <= 3'd0;
// then as before: PRE_OBJ0_IDLE, lineindex <= 0, containercount + 1, object0 <= 0, EOFt
```

*Case B3: last stream, not the last line.* Go to the next line. Your original code, plus:

```verilog
stream        <= 3'd0;
seq_line_base <= seq_count;              // base for the next line's slots
// then as before: END_LINE_IDLE, lineindex + 1, EOFn
```

For `NUM_STREAMS = 1`, case B1 can never happen (`stream != 0` is never true), so B2 and B3 are exactly your original code.

**Branch C: an FC frame in the middle of a line ended.** Unchanged.

### 6.7 How SEQ_CNT stays correct per stream

All streams share your one `seq_count` register, which is rewound when switching streams. Example with 2 frames per line:

| Event | seq_count | seq_line_base |
|---|---|---|
| Obj0 s0, Obj0 s1 | 0 | 0 |
| line 0 s0 f0, f1 | 1, 2 | 0 |
| switch to s1: `seq_count <= seq_line_base` | 0 | 0 |
| line 0 s1 f0, f1 | 1, 2 | 0 |
| next line: `seq_line_base <= seq_count` | 2 | 2 |
| line 1 s0 f0, f1 | 3, 4 | 2 |
| switch to s1 | 2 | 2 |
| line 1 s1 f0, f1 | 3, 4 | 2 |

Each stream sees 0, 1, 2, 3, ..., exactly like a single-stream sequence. No per-stream copies of the counters are needed, because all streams are always on the same line.

### 6.8 What was not touched in `advbtx`

All of the following is identical to your code:

- all localparams and the `select_frame_rate_code` and `select_idles` tables;
- the ordered sets, `running_disp`, `nextcrc32` and `crc_data`;
- `ancillaryheader` and `containerheader`;
- the next-state logic and the IDLE, SENDSOF, SENDHDR, SENDCONT, SENDANC, SENDPAYLOAD and SENDCRC states;
- the output byte swap.

The old `DEST_ID` and `SRC_ID` localparams are still in the file but no longer used.

---

## 7. `stream_select.v` (new): how the receive filter works

It sits between `sync` and `advbrx`. Parameters: `MATCH_DID` and `MATCH_SID`.

**1. Delay line.** The incoming words pass through three registers: `d0` (newest), `d1`, `d2`.

**2. Finding a frame start (SOF).** A K-character word followed directly by data words is an SOF. Idles are K followed by K, and EOF is K after data, so neither is mistaken for an SOF.

```verilog
sof_at_d2 = (k2 != 0) && (k1 == 0) && (k0 == 0);
```

At that moment `d2` holds the SOF, `d1` holds header word 0 `{R_CTL, D_ID}` and `d0` holds header word 1 `{CS_CTL, S_ID}`. The filter can therefore decide **before the SOF leaves**.

**3. Byte order.**

- If the SOF's K character is in byte 0 (`charisk = 4'b0001`), the bus is LSB-first and the header bytes are swapped before comparing.
- If it is in byte 3 (`4'b1000`), they are compared as they are.

So the block works whichever byte order your `rxdata_formater` and `sync` produce.

**4. Decision.**

```verilog
id_match = (hdr0[23:0] == MATCH_DID) && (hdr1[23:0] == MATCH_SID);
```

The decision is held in `pass` from the SOF to the EOF of that frame.

**5. Output.**

- Words of a matching frame, and idles between frames, pass **unchanged**.
- Every word of a non-matching frame is replaced by an idle word.
- The idle word is a **copy of the last real idle seen on the bus**, so it is always in the bus's own byte order and has the correct K flags.

**6. Latency:** 4 clocks. `advbrx` simply sees its frames 4 clocks later.

The result is that each `advbrx` sees "its frames, separated by idles", which is the same as a normal single-stream link with longer gaps.

---

## 8. Settings summary

| Want | Set |
|---|---|
| Original single-stream behaviour | `arinc818_top` → `NUM_STREAMS = 1` |
| 2 to 8 streams | `arinc818_top` → `NUM_STREAMS = 2 ... 8` |
| Change the IDs | `arinc818_core` → `STREAM_SRC_ID` / `STREAM_DEST_ID` (rightmost entry = stream 0) |
| Input is a single-stream source (copy to all streams) | `arinc818_core` → `RX_FANOUT = 1` |
| Input already carries N streams (separate by ID) | `arinc818_core` → `RX_FANOUT = 0` |
| Change the gap between stream slots | `END_LINE_IDLE` in your `select_idles` table |

---

## 9. Link bandwidth: please read before testing on hardware

This is a property of the link, not of the code.

Your 1280x1024 idle values make one video frame exactly:

```
PRE 45607 + Obj0 35 + POST 1169 + 1024 x (2 x 489 + 6) + 1023 x 262  =  1,322,453 words
```

(An FC frame = SOF + 6 header + 480 payload + CRC + EOF = 489 words. Obj0 = 35 words.)

At 60 Hz that is about 79.3 M words/s, which is the word rate of a **3.1875 Gbps** link (79.69 M words/s). **One stream already uses almost all of it.**

With 2 streams and your idles unchanged, one cycle through all streams is:

```
PRE 45607 + 2 x 35 + 6 + POST 1169 + 2048 x 984 + 2047 x 262  =  2,598,398 words
```

On 3.1875 Gbps that gives **30.7 frames per second per stream**.

What this means:

1. **Two 1280x1024 streams at 60 Hz cannot fit on 3.1875 Gbps.** The pixel data alone needs about 118 M words/s. You need a faster line rate, about 5 Gbps or more (for example 6.375 Gbps).
2. **Two streams at exactly 30 Hz on 3.1875 Gbps:**
   - in `select_idles`, change the 1280x1024 `PRE` value from `45607` to `103459`;
   - in `arinc818_core`, change `advbtx` to `.FRAMERATE(30)`, so container word 4 reports 30 Hz.
3. **`RX_FANOUT = 1` with a 60 Hz source on 3.1875 Gbps will overflow the FIFOs.** The input arrives at 60 Hz, but each stream can only be sent at about 30 Hz, so the picture tears. Test fanout with a source at 30 Hz or less, or with a lower resolution.
4. **With `RX_FANOUT = 0`, the incoming link must be line-interleaved,** as this transmitter produces. Each stream FIFO is 2048 words, about 2 lines.

---

## 10. How it was verified

The simulator was Icarus Verilog 12. The testbench is `ARINC818_MultiStream_FromWorking/sim/tb_multistream.v`.

| Check | Result |
|---|---|
| `NUM_STREAMS = 1`: new `advbtx` against your **original** `advbtx`, side by side, both fed from real `asyncfifo`s with identical data, every output word compared | **0 differences** in 102,985 clock cycles |
| 1, 2 and 3 streams, 3 video frames each. Every frame checked for order, D_ID, S_ID, SOFi/SOFn, EOFn/EOFt, SEQ_ID, SEQ_CNT, END_SEQ, every payload word (right stream, right order) and every idle gap length | **PASS** (27, 54 and 81 frames) |
| CRC of every frame against a separate, independently written CRC-32 model | **Matches.** This also independently confirms your CRC. |
| `stream_select` for each stream, on both bus byte orders: own frames exact, all other frames replaced by idles | **PASS** |
| Three bugs inserted on purpose (SEQ_CNT not rewound, filter passing everything, same S_ID on all streams) | **All 3 caught** |
| `arinc818_top` and `arinc818_core` compile and elaborate with 1, 2 and 8 streams, fanout and demux | **Clean, no warnings** |
| Full 1280x1024 runs (1 stream against your original, and 2 streams) | Running at the time of writing; result reported separately |

**Not simulated:** your current `advbrx`, the GTH transceiver and the clock wizard, because their source is not on this PC. For the compile check, port-only stand-ins with the same port names as your core uses were used. Please run a Vivado synthesis at work.

---

## 11. Hardware bring-up checklist

1. **Build with `NUM_STREAMS = 1` first.** It must behave exactly like your current working design. This proves the new files are integrated correctly.
2. **Go to `NUM_STREAMS = 2`, `RX_FANOUT = 1`,** with a source at 30 Hz or less (see section 9). Check with your viewer or analyser that two streams appear, with S_ID `000001` and `000002`.
3. **ILA:** `txfifo_rdata` inside `transmit` is still marked for debug. Also useful to probe:
   - `transmit/stream`
   - `transmit/state`
   - `transmit/seq_count`
4. **For a multistream input,** set `RX_FANOUT = 0` and make sure the ID table matches the IDs the incoming source uses.
