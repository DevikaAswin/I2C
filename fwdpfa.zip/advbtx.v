module advbtx #(
  parameter HACTIVE   = 1280,
  parameter VACTIVE   = 1024,
  parameter FRAMERATE = 60,
  parameter BytesPerPixel=3,
  // ---------------- MULTISTREAM (new) ----------------
  // NUM_STREAMS = 1 gives exactly the original single-stream output.
  // Max 8 streams. Stream k uses bits [24*k +: 24] of the two ID lists.
  // Each stream must have a unique SRC_ID or DEST_ID (ARINC 818 multistream).
  parameter NUM_STREAMS = 1,
  parameter [191:0] STREAM_SRC_ID  = {24'h000008, 24'h000007, 24'h000006, 24'h000005,
                                      24'h000004, 24'h000003, 24'h000002, 24'h000001},
  parameter [191:0] STREAM_DEST_ID = {8{24'h007912}}
)(
  input             clk,
  input             rst_n,
  output     [31:0] advb_txdata,
  output     [3:0]  advb_txcharisk,
  // one FIFO per stream (stream k = bit k / bits [32*k +: 32])
  input      [NUM_STREAMS-1:0]    txfifo_rempty_all,
  output     [NUM_STREAMS-1:0]    txfifo_rden_all,
  input      [32*NUM_STREAMS-1:0] txfifo_rdata_all
);

// ---------------- MULTISTREAM (new) ----------------
// 'stream' = which video stream the FSM is sending right now.
// The original FSM below still uses txfifo_rempty / txfifo_rden / txfifo_rdata;
// these now point at the FIFO of the current stream, so the FSM is unchanged.
reg  [2:0]  stream;
reg  [15:0] seq_line_base;   // SEQ_CNT at the start of the current line slot
reg         txfifo_rden;
wire        txfifo_rempty = txfifo_rempty_all[stream];
(* DONT_TOUCH = "TRUE", MARK_DEBUG = "TRUE" *) wire [31:0] txfifo_rdata = txfifo_rdata_all[32*stream +: 32];
wire [23:0] cur_dest_id   = STREAM_DEST_ID[24*stream +: 24];
wire [23:0] cur_src_id    = STREAM_SRC_ID [24*stream +: 24];

genvar g;
generate
  for (g = 0; g < NUM_STREAMS; g = g + 1) begin : g_rden
    assign txfifo_rden_all[g] = txfifo_rden & (stream == g);
  end
endgenerate


localparam HEADERWORDS       = 6;     // FC frame header,
localparam CONTAINERWORDS    = 22;    //  22 words long
localparam ANCILLARYWORDS    = 4;     // 16 bytes


localparam [7:0]  TX_RATE_CODE   = 8'h01;     //  transmit at the frame rate
localparam [7:0]  CONTAINER_MODE = 8'h00;     // Simple mode
localparam [7:0]  NUM_OBJECTS    = 8'h04;
localparam [7:0]  EXT_HDR_SIZE   = 8'h00;
localparam [7:0]  OBJ_CLASS_ANC  = 8'h50;     // ancillary, uncompressed
localparam [7:0]  OBJ_CLASS_AUD  = 8'h40;     // audio, uncompressed
localparam [7:0]  OBJ_CLASS_VID  = 8'h10;     //  video, uncompressed
localparam [7:0]  LINK_POINTER   = 8'h00;     //  not used
localparam [15:0] SPDV_INDEX     = 16'hD000;  //uncompressed index type
localparam [3:0]  FRAME_FIELD    = 4'h0;      //  full video frame
localparam   PRIOR_CRC      = 1'b0;      // obj0 Word 2 carries no CRC
localparam [2:0]  PIXEL_ASPECT   = 3'h0;      //  1:1
localparam [3:0]  PIXEL_ORDER    = 4'h0;      //  left->right, top->bottom
localparam [3:0]  PACKING_TBL    = 4'h0;      //  8-bit components
localparam [3:0]  BITS_SUBPIX    = 4'h7;      //  8 bits, carried as 8-1
localparam [3:0]  COLOR_INFO      = 4'h1;

localparam [7:0]  R_CTL     = 8'h44;
localparam [23:0] DEST_ID   = 24'h007912;
localparam [23:0] SRC_ID    = 24'h000001;
localparam [7:0]  FC_TYPE   = 8'h61;          // ADVB
localparam [23:0] F_CTL_MID = 24'h300000;     // sequence continues
localparam [23:0] F_CTL_END = 24'h380000;     // bit 19 END_SEQ, last frame


// (Container word 4, byte 0)

function [7:0] select_frame_rate_code;
  input integer fr;
  begin
    case (fr)
       15     : select_frame_rate_code = 8'h01;
       20     : select_frame_rate_code = 8'h02;
       24     : select_frame_rate_code = 8'h03;
       25     : select_frame_rate_code = 8'h44;
       30     : select_frame_rate_code = 8'h45;
       50     : select_frame_rate_code = 8'h06;
       60     : select_frame_rate_code = 8'h07;
       75     : select_frame_rate_code = 8'h0A;
       85     : select_frame_rate_code = 8'h0B;
      120     : select_frame_rate_code = 8'h04;
      default : select_frame_rate_code = 8'hFF;
    endcase
  end
endfunction




function [95:0] select_idles;
  input integer h;
  input integer v;
  begin
    case ({h[15:0], v[15:0]})
      //                                 PRE        POST      INTER    END_LINE
      {16'd640,  16'd480 } : select_idles = {32'd969063, 32'd36658, 16'd6, 16'd1087};
      {16'd800,  16'd600 } : select_idles = {32'd777794, 32'd36658, 16'd6, 16'd967};
      {16'd1024, 16'd768 } : select_idles = {32'd510018, 32'd36658, 16'd6, 16'd799};
      {16'd1280, 16'd720 } : select_idles = {32'd586526, 32'd36658, 16'd6, 16'd607};
      {16'd1280, 16'd800 } : select_idles = {32'd459013, 32'd36658, 16'd6, 16'd607};
      {16'd1280, 16'd1024} : select_idles = {32'd45607, 32'd1169, 16'd6, 16'd262};
      {16'd1440, 16'd900 } : select_idles = {32'd299624, 32'd36656, 16'd6, 16'd487};
//      {16'd1600, 16'd1200} : select_idles = {32'd45303, 32'd3555, 16'd6, 16'd367};
      {16'd1680, 16'd1050} : select_idles = {32'd60547, 32'd36647, 16'd6, 16'd307};
      {16'd1920, 16'd1080} : select_idles = {32'd45303, 32'd3555, 16'd6, 16'd80};
      {16'd1920, 16'd1200} : select_idles = {32'd45303, 32'd3555, 16'd6, 16'd80};
      {16'd2048, 16'd1080} : select_idles = {32'd45303, 32'd3555, 16'd6, 16'd80};
      {16'd2560, 16'd1440} : select_idles = {32'd45303, 32'd3555, 16'd6, 16'd80};
      {16'd2560, 16'd1600} : select_idles = {32'd45303, 32'd3555, 16'd6, 16'd80};
      {16'd3840, 16'd2160} : select_idles = {32'd45303, 32'd3555, 16'd6, 16'd80};
      default              : select_idles = {32'd45303, 32'd3555, 16'd6, 16'd80};
    endcase
  end
endfunction

localparam        WORDSPERLINE    = HACTIVE * BytesPerPixel / 4;
localparam [7:0]  FRAME_RATE_CODE = select_frame_rate_code(FRAMERATE);
localparam MAX_WORDS_FRAME = 528;

localparam FRAMESPERLINE   = 2;//(WORDSPERLINE + MAX_WORDS_FRAME) / MAX_WORDS_FRAME; //4


localparam        PAYLOADWORDS    = (WORDSPERLINE / FRAMESPERLINE);

localparam [95:0] IDLES           = select_idles(HACTIVE, VACTIVE);
localparam        PRE_OBJ0_IDLE   = IDLES[95:64];
localparam        POST_OBJ0_IDLE  = IDLES[63:32];
localparam        INTER_OBJ2_IDLE = IDLES[31:16];
localparam        END_LINE_IDLE   = IDLES[15:0];


localparam        TOTALOBJ2FRAMES = VACTIVE * FRAMESPERLINE;


localparam [31:0] OBJ0_SIZE   = ANCILLARYWORDS * 4;                 // 10h
localparam [31:0] OBJ0_OFFSET = CONTAINERWORDS * 4;                 // 58h
localparam [31:0] OBJ1_SIZE   = 0;                                  // no audio
localparam [31:0] OBJ1_OFFSET = OBJ0_OFFSET + OBJ0_SIZE;            // 68h
localparam [31:0] OBJ2_SIZE   = HACTIVE * VACTIVE * BytesPerPixel;  // 3.2.4.2 dbt
localparam [31:0] OBJ2_OFFSET = OBJ1_OFFSET + OBJ1_SIZE;            // 3.2.4.3
localparam [31:0] OBJ3_SIZE   = 0;                                  // progressive 3.2.4.6
localparam [31:0] OBJ3_OFFSET = OBJ2_OFFSET + OBJ2_SIZE;            // 3.2.4.7


localparam [13:0] ROWS      = VACTIVE;
localparam [13:0] COLS      = HACTIVE;
localparam [31:0] ANC_WORD0 = {ROWS, COLS, FRAME_FIELD};
localparam [31:0] ANC_WORD1 = {COLOR_INFO, PRIOR_CRC, PIXEL_ASPECT, PIXEL_ORDER,
                               PACKING_TBL, BITS_SUBPIX, BITS_SUBPIX,
                               BITS_SUBPIX, BITS_SUBPIX};


localparam IDLE_CW = 32;
localparam WORD_CW = 10;
localparam LINE_CW = 14;
localparam FIL_CW  = 4;
localparam HDR_CW  = 3;
localparam CON_CW  = 5;


localparam IDLEWORD    = 32'hBC95B5B5;   // K28.5 D21.4 D21.5 D21.5
localparam SOFIWORD    = 32'hBCB55757;   // K28.5 D21.5 D23.2 D23.2  SOFi1
localparam SOFNWORD    = 32'hBCB53737;   // K28.5 D21.5 D23.1 D23.1  SOFn1
localparam EOFN_NEG_RD = 32'hBC95D5D5;   // K28.5 D21.4 D21.6 D21.6
localparam EOFN_POS_RD = 32'hBCB5D5D5;   // K28.5 D21.5 D21.6 D21.6
localparam EOFT_NEG_RD = 32'hBC957575;   // K28.5 D21.4 D21.3 D21.3
localparam EOFT_POS_RD = 32'hBCB57575;   // K28.5 D21.5 D21.3 D21.3


localparam IDLE        = 3'd0;
localparam SENDSOF     = 3'd1;
localparam SENDHDR     = 3'd2;
localparam SENDCONT    = 3'd3;
localparam SENDANC     = 3'd4;
localparam SENDPAYLOAD = 3'd5;
localparam SENDCRC     = 3'd6;
localparam SENDEOF     = 3'd7;


reg [31:0] xcvr_txdata;
reg [3:0]  xcvr_txcharisk;
reg [2:0]  state;
reg [2:0]  nextstate;
reg [31:0] containercount;
reg [15:0] seq_count;
reg [LINE_CW-1:0] lineindex;
reg [IDLE_CW-1:0] idle_counter;
reg [IDLE_CW-1:0] idle_target;
reg [FIL_CW-1:0]  frame_in_line;      // FRAMESPERLINE-1
reg [WORD_CW-1:0] wordcounter;
reg [HDR_CW-1:0]  frame_hdrcnt;
reg [CON_CW-1:0]  container_hdrcnt;
reg        lastframe;
reg        object0;


reg disp_byte0, disp_byte1, disp_byte2, next_rd;
reg current_rd;

function running_disp;
  input [7:0] txdata;
  input       txcharisk;
  input       prev_disp;
  reg   [4:0] sub_5b;
  reg   [2:0] sub_3b;
  reg         disp_flip;
  begin
    if (txcharisk) begin
      // K-Character (Control) Disparity Rules
      case (txdata)
        8'h1C, 8'h3C, 8'h5C, 8'h7C, 8'h9C, 8'hBC, 8'hDC, 8'hFC:
          begin
            // K28.x characters always flip running disparity
            disp_flip = 1'b1;
          end
        8'h17, 8'h37, 8'h57, 8'h77:
          begin
            // K23.7, K27.7, K29.7, K30.7 are disparity-neutral
            disp_flip = 1'b0;
          end
        default:
          begin
            disp_flip = 1'b0;
          end
      endcase
    end else begin
      sub_5b = txdata[4:0];
      sub_3b = txdata[7:5];
      // D-character disparity based on 5b/3b sub-block analysis
      disp_flip = (sub_5b == 5'd0  || sub_5b == 5'd1  ||
                   sub_5b == 5'd2  || sub_5b == 5'd4  ||
                   sub_5b == 5'd8  || sub_5b == 5'd11 ||
                   sub_5b == 5'd12 || sub_5b == 5'd13 ||
                   sub_5b == 5'd14 || sub_5b == 5'd15 ||
                   sub_5b == 5'd16 || sub_5b == 5'd19 ||
                   sub_5b == 5'd20 || sub_5b == 5'd21 ||
                   sub_5b == 5'd22 || sub_5b == 5'd25 ||
                   sub_5b == 5'd26 || sub_5b == 5'd27 ||
                   sub_5b == 5'd28 || sub_5b == 5'd31)
                   ^
                   (sub_3b == 3'd0  || sub_3b == 3'd3  ||
                    sub_3b == 3'd4  || sub_3b == 3'd7);
    end
    if (disp_flip == 1'b1)
      running_disp = ~prev_disp;
    else
      running_disp = prev_disp;
  end
endfunction

always @(*)
begin
  disp_byte0 = running_disp(advb_txdata[7:0],   advb_txcharisk[0], current_rd);
  disp_byte1 = running_disp(advb_txdata[15:8],  advb_txcharisk[1], disp_byte0);
  disp_byte2 = running_disp(advb_txdata[23:16], advb_txcharisk[2], disp_byte1);
  next_rd    = running_disp(advb_txdata[31:24], advb_txcharisk[3], disp_byte2);
end

always @(posedge clk or negedge rst_n)
begin
  if (!rst_n)
    current_rd <= 1'b0;
  else
    current_rd <= next_rd;
end


wire       crc_en;
reg [31:0] crc_data;
reg [31:0] lfsr_q_r, crc_accum;
integer    i;

function [31:0] nextcrc32;
  input [31:0] crc;
  input [31:0] data;
  integer i;
  reg [31:0] data_trans, lfsr_c, lfsr_q;
  begin
    lfsr_q = crc;
    // Bit-reverse each byte for FC byte ordering
    for (i=0; i<8;i=i+1)
    begin
      data_trans[i+24] = data[31-i];
      data_trans[i+16] = data[23-i];
      data_trans[i+8]  = data[15-i];
      data_trans[i]    = data[7-i];
    end

    lfsr_c[0] = lfsr_q[0] ^ lfsr_q[6] ^ lfsr_q[9] ^ lfsr_q[10] ^ lfsr_q[12] ^ lfsr_q[16] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[26] ^ lfsr_q[28] ^ lfsr_q[29] ^ lfsr_q[30] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[6] ^ data_trans[9] ^ data_trans[10] ^ data_trans[12] ^ data_trans[16] ^ data_trans[24] ^ data_trans[25] ^ data_trans[26] ^ data_trans[28] ^ data_trans[29] ^ data_trans[30] ^ data_trans[31];
    lfsr_c[1] = lfsr_q[0] ^ lfsr_q[1] ^ lfsr_q[6] ^ lfsr_q[7] ^ lfsr_q[9] ^ lfsr_q[11] ^ lfsr_q[12] ^ lfsr_q[13] ^ lfsr_q[16] ^ lfsr_q[17] ^ lfsr_q[24] ^ lfsr_q[27] ^ lfsr_q[28] ^ data_trans[0] ^ data_trans[1] ^ data_trans[6] ^ data_trans[7] ^ data_trans[9] ^ data_trans[11] ^ data_trans[12] ^ data_trans[13] ^ data_trans[16] ^ data_trans[17] ^ data_trans[24] ^ data_trans[27] ^ data_trans[28];
    lfsr_c[2] = lfsr_q[0] ^ lfsr_q[1] ^ lfsr_q[2] ^ lfsr_q[6] ^ lfsr_q[7] ^ lfsr_q[8] ^ lfsr_q[9] ^ lfsr_q[13] ^ lfsr_q[14] ^ lfsr_q[16] ^ lfsr_q[17] ^ lfsr_q[18] ^ lfsr_q[24] ^ lfsr_q[26] ^ lfsr_q[30] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[1] ^ data_trans[2] ^ data_trans[6] ^ data_trans[7] ^ data_trans[8] ^ data_trans[9] ^ data_trans[13] ^ data_trans[14] ^ data_trans[16] ^ data_trans[17] ^ data_trans[18] ^ data_trans[24] ^ data_trans[26] ^ data_trans[30] ^ data_trans[31];
    lfsr_c[3] = lfsr_q[1] ^ lfsr_q[2] ^ lfsr_q[3] ^ lfsr_q[7] ^ lfsr_q[8] ^ lfsr_q[9] ^ lfsr_q[10] ^ lfsr_q[14] ^ lfsr_q[15] ^ lfsr_q[17] ^ lfsr_q[18] ^ lfsr_q[19] ^ lfsr_q[25] ^ lfsr_q[27] ^ lfsr_q[31] ^ data_trans[1] ^ data_trans[2] ^ data_trans[3] ^ data_trans[7] ^ data_trans[8] ^ data_trans[9] ^ data_trans[10] ^ data_trans[14] ^ data_trans[15] ^ data_trans[17] ^ data_trans[18] ^ data_trans[19] ^ data_trans[25] ^ data_trans[27] ^ data_trans[31];
    lfsr_c[4] = lfsr_q[0] ^ lfsr_q[2] ^ lfsr_q[3] ^ lfsr_q[4] ^ lfsr_q[6] ^ lfsr_q[8] ^ lfsr_q[11] ^ lfsr_q[12] ^ lfsr_q[15] ^ lfsr_q[18] ^ lfsr_q[19] ^ lfsr_q[20] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[29] ^ lfsr_q[30] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[2] ^ data_trans[3] ^ data_trans[4] ^ data_trans[6] ^ data_trans[8] ^ data_trans[11] ^ data_trans[12] ^ data_trans[15] ^ data_trans[18] ^ data_trans[19] ^ data_trans[20] ^ data_trans[24] ^ data_trans[25] ^ data_trans[29] ^ data_trans[30] ^ data_trans[31];
    lfsr_c[5] = lfsr_q[0] ^ lfsr_q[1] ^ lfsr_q[3] ^ lfsr_q[4] ^ lfsr_q[5] ^ lfsr_q[6] ^ lfsr_q[7] ^ lfsr_q[10] ^ lfsr_q[13] ^ lfsr_q[19] ^ lfsr_q[20] ^ lfsr_q[21] ^ lfsr_q[24] ^ lfsr_q[28] ^ lfsr_q[29] ^ data_trans[0] ^ data_trans[1] ^ data_trans[3] ^ data_trans[4] ^ data_trans[5] ^ data_trans[6] ^ data_trans[7] ^ data_trans[10] ^ data_trans[13] ^ data_trans[19] ^ data_trans[20] ^ data_trans[21] ^ data_trans[24] ^ data_trans[28] ^ data_trans[29];
    lfsr_c[6] = lfsr_q[1] ^ lfsr_q[2] ^ lfsr_q[4] ^ lfsr_q[5] ^ lfsr_q[6] ^ lfsr_q[7] ^ lfsr_q[8] ^ lfsr_q[11] ^ lfsr_q[14] ^ lfsr_q[20] ^ lfsr_q[21] ^ lfsr_q[22] ^ lfsr_q[25] ^ lfsr_q[29] ^ lfsr_q[30] ^ data_trans[1] ^ data_trans[2] ^ data_trans[4] ^ data_trans[5] ^ data_trans[6] ^ data_trans[7] ^ data_trans[8] ^ data_trans[11] ^ data_trans[14] ^ data_trans[20] ^ data_trans[21] ^ data_trans[22] ^ data_trans[25] ^ data_trans[29] ^ data_trans[30];
    lfsr_c[7] = lfsr_q[0] ^ lfsr_q[2] ^ lfsr_q[3] ^ lfsr_q[5] ^ lfsr_q[7] ^ lfsr_q[8] ^ lfsr_q[10] ^ lfsr_q[15] ^ lfsr_q[16] ^ lfsr_q[21] ^ lfsr_q[22] ^ lfsr_q[23] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[28] ^ lfsr_q[29] ^ data_trans[0] ^ data_trans[2] ^ data_trans[3] ^ data_trans[5] ^ data_trans[7] ^ data_trans[8] ^ data_trans[10] ^ data_trans[15] ^ data_trans[16] ^ data_trans[21] ^ data_trans[22] ^ data_trans[23] ^ data_trans[24] ^ data_trans[25] ^ data_trans[28] ^ data_trans[29];
    lfsr_c[8] = lfsr_q[0] ^ lfsr_q[1] ^ lfsr_q[3] ^ lfsr_q[4] ^ lfsr_q[8] ^ lfsr_q[10] ^ lfsr_q[11] ^ lfsr_q[12] ^ lfsr_q[17] ^ lfsr_q[22] ^ lfsr_q[23] ^ lfsr_q[28] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[1] ^ data_trans[3] ^ data_trans[4] ^ data_trans[8] ^ data_trans[10] ^ data_trans[11] ^ data_trans[12] ^ data_trans[17] ^ data_trans[22] ^ data_trans[23] ^ data_trans[28] ^ data_trans[31];
    lfsr_c[9] = lfsr_q[1] ^ lfsr_q[2] ^ lfsr_q[4] ^ lfsr_q[5] ^ lfsr_q[9] ^ lfsr_q[11] ^ lfsr_q[12] ^ lfsr_q[13] ^ lfsr_q[18] ^ lfsr_q[23] ^ lfsr_q[24] ^ lfsr_q[29] ^ data_trans[1] ^ data_trans[2] ^ data_trans[4] ^ data_trans[5] ^ data_trans[9] ^ data_trans[11] ^ data_trans[12] ^ data_trans[13] ^ data_trans[18] ^ data_trans[23] ^ data_trans[24] ^ data_trans[29];
    lfsr_c[10] = lfsr_q[0] ^ lfsr_q[2] ^ lfsr_q[3] ^ lfsr_q[5] ^ lfsr_q[9] ^ lfsr_q[13] ^ lfsr_q[14] ^ lfsr_q[16] ^ lfsr_q[19] ^ lfsr_q[26] ^ lfsr_q[28] ^ lfsr_q[29] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[2] ^ data_trans[3] ^ data_trans[5] ^ data_trans[9] ^ data_trans[13] ^ data_trans[14] ^ data_trans[16] ^ data_trans[19] ^ data_trans[26] ^ data_trans[28] ^ data_trans[29] ^ data_trans[31];
    lfsr_c[11] = lfsr_q[0] ^ lfsr_q[1] ^ lfsr_q[3] ^ lfsr_q[4] ^ lfsr_q[9] ^ lfsr_q[12] ^ lfsr_q[14] ^ lfsr_q[15] ^ lfsr_q[16] ^ lfsr_q[17] ^ lfsr_q[20] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[26] ^ lfsr_q[27] ^ lfsr_q[28] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[1] ^ data_trans[3] ^ data_trans[4] ^ data_trans[9] ^ data_trans[12] ^ data_trans[14] ^ data_trans[15] ^ data_trans[16] ^ data_trans[17] ^ data_trans[20] ^ data_trans[24] ^ data_trans[25] ^ data_trans[26] ^ data_trans[27] ^ data_trans[28] ^ data_trans[31];
    lfsr_c[12] = lfsr_q[0] ^ lfsr_q[1] ^ lfsr_q[2] ^ lfsr_q[4] ^ lfsr_q[5] ^ lfsr_q[6] ^ lfsr_q[9] ^ lfsr_q[12] ^ lfsr_q[13] ^ lfsr_q[15] ^ lfsr_q[17] ^ lfsr_q[18] ^ lfsr_q[21] ^ lfsr_q[24] ^ lfsr_q[27] ^ lfsr_q[30] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[1] ^ data_trans[2] ^ data_trans[4] ^ data_trans[5] ^ data_trans[6] ^ data_trans[9] ^ data_trans[12] ^ data_trans[13] ^ data_trans[15] ^ data_trans[17] ^ data_trans[18] ^ data_trans[21] ^ data_trans[24] ^ data_trans[27] ^ data_trans[30] ^ data_trans[31];
    lfsr_c[13] = lfsr_q[1] ^ lfsr_q[2] ^ lfsr_q[3] ^ lfsr_q[5] ^ lfsr_q[6] ^ lfsr_q[7] ^ lfsr_q[10] ^ lfsr_q[13] ^ lfsr_q[14] ^ lfsr_q[16] ^ lfsr_q[18] ^ lfsr_q[19] ^ lfsr_q[22] ^ lfsr_q[25] ^ lfsr_q[28] ^ lfsr_q[31] ^ data_trans[1] ^ data_trans[2] ^ data_trans[3] ^ data_trans[5] ^ data_trans[6] ^ data_trans[7] ^ data_trans[10] ^ data_trans[13] ^ data_trans[14] ^ data_trans[16] ^ data_trans[18] ^ data_trans[19] ^ data_trans[22] ^ data_trans[25] ^ data_trans[28] ^ data_trans[31];
    lfsr_c[14] = lfsr_q[2] ^ lfsr_q[3] ^ lfsr_q[4] ^ lfsr_q[6] ^ lfsr_q[7] ^ lfsr_q[8] ^ lfsr_q[11] ^ lfsr_q[14] ^ lfsr_q[15] ^ lfsr_q[17] ^ lfsr_q[19] ^ lfsr_q[20] ^ lfsr_q[23] ^ lfsr_q[26] ^ lfsr_q[29] ^ data_trans[2] ^ data_trans[3] ^ data_trans[4] ^ data_trans[6] ^ data_trans[7] ^ data_trans[8] ^ data_trans[11] ^ data_trans[14] ^ data_trans[15] ^ data_trans[17] ^ data_trans[19] ^ data_trans[20] ^ data_trans[23] ^ data_trans[26] ^ data_trans[29];
    lfsr_c[15] = lfsr_q[3] ^ lfsr_q[4] ^ lfsr_q[5] ^ lfsr_q[7] ^ lfsr_q[8] ^ lfsr_q[9] ^ lfsr_q[12] ^ lfsr_q[15] ^ lfsr_q[16] ^ lfsr_q[18] ^ lfsr_q[20] ^ lfsr_q[21] ^ lfsr_q[24] ^ lfsr_q[27] ^ lfsr_q[30] ^ data_trans[3] ^ data_trans[4] ^ data_trans[5] ^ data_trans[7] ^ data_trans[8] ^ data_trans[9] ^ data_trans[12] ^ data_trans[15] ^ data_trans[16] ^ data_trans[18] ^ data_trans[20] ^ data_trans[21] ^ data_trans[24] ^ data_trans[27] ^ data_trans[30];
    lfsr_c[16] = lfsr_q[0] ^ lfsr_q[4] ^ lfsr_q[5] ^ lfsr_q[8] ^ lfsr_q[12] ^ lfsr_q[13] ^ lfsr_q[17] ^ lfsr_q[19] ^ lfsr_q[21] ^ lfsr_q[22] ^ lfsr_q[24] ^ lfsr_q[26] ^ lfsr_q[29] ^ lfsr_q[30] ^ data_trans[0] ^ data_trans[4] ^ data_trans[5] ^ data_trans[8] ^ data_trans[12] ^ data_trans[13] ^ data_trans[17] ^ data_trans[19] ^ data_trans[21] ^ data_trans[22] ^ data_trans[24] ^ data_trans[26] ^ data_trans[29] ^ data_trans[30];
    lfsr_c[17] = lfsr_q[1] ^ lfsr_q[5] ^ lfsr_q[6] ^ lfsr_q[9] ^ lfsr_q[13] ^ lfsr_q[14] ^ lfsr_q[18] ^ lfsr_q[20] ^ lfsr_q[22] ^ lfsr_q[23] ^ lfsr_q[25] ^ lfsr_q[27] ^ lfsr_q[30] ^ lfsr_q[31] ^ data_trans[1] ^ data_trans[5] ^ data_trans[6] ^ data_trans[9] ^ data_trans[13] ^ data_trans[14] ^ data_trans[18] ^ data_trans[20] ^ data_trans[22] ^ data_trans[23] ^ data_trans[25] ^ data_trans[27] ^ data_trans[30] ^ data_trans[31];
    lfsr_c[18] = lfsr_q[2] ^ lfsr_q[6] ^ lfsr_q[7] ^ lfsr_q[10] ^ lfsr_q[14] ^ lfsr_q[15] ^ lfsr_q[19] ^ lfsr_q[21] ^ lfsr_q[23] ^ lfsr_q[24] ^ lfsr_q[26] ^ lfsr_q[28] ^ lfsr_q[31] ^ data_trans[2] ^ data_trans[6] ^ data_trans[7] ^ data_trans[10] ^ data_trans[14] ^ data_trans[15] ^ data_trans[19] ^ data_trans[21] ^ data_trans[23] ^ data_trans[24] ^ data_trans[26] ^ data_trans[28] ^ data_trans[31];
    lfsr_c[19] = lfsr_q[3] ^ lfsr_q[7] ^ lfsr_q[8] ^ lfsr_q[11] ^ lfsr_q[15] ^ lfsr_q[16] ^ lfsr_q[20] ^ lfsr_q[22] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[27] ^ lfsr_q[29] ^ data_trans[3] ^ data_trans[7] ^ data_trans[8] ^ data_trans[11] ^ data_trans[15] ^ data_trans[16] ^ data_trans[20] ^ data_trans[22] ^ data_trans[24] ^ data_trans[25] ^ data_trans[27] ^ data_trans[29];
    lfsr_c[20] = lfsr_q[4] ^ lfsr_q[8] ^ lfsr_q[9] ^ lfsr_q[12] ^ lfsr_q[16] ^ lfsr_q[17] ^ lfsr_q[21] ^ lfsr_q[23] ^ lfsr_q[25] ^ lfsr_q[26] ^ lfsr_q[28] ^ lfsr_q[30] ^ data_trans[4] ^ data_trans[8] ^ data_trans[9] ^ data_trans[12] ^ data_trans[16] ^ data_trans[17] ^ data_trans[21] ^ data_trans[23] ^ data_trans[25] ^ data_trans[26] ^ data_trans[28] ^ data_trans[30];
    lfsr_c[21] = lfsr_q[5] ^ lfsr_q[9] ^ lfsr_q[10] ^ lfsr_q[13] ^ lfsr_q[17] ^ lfsr_q[18] ^ lfsr_q[22] ^ lfsr_q[24] ^ lfsr_q[26] ^ lfsr_q[27] ^ lfsr_q[29] ^ lfsr_q[31] ^ data_trans[5] ^ data_trans[9] ^ data_trans[10] ^ data_trans[13] ^ data_trans[17] ^ data_trans[18] ^ data_trans[22] ^ data_trans[24] ^ data_trans[26] ^ data_trans[27] ^ data_trans[29] ^ data_trans[31];
    lfsr_c[22] = lfsr_q[0] ^ lfsr_q[9] ^ lfsr_q[11] ^ lfsr_q[12] ^ lfsr_q[14] ^ lfsr_q[16] ^ lfsr_q[18] ^ lfsr_q[19] ^ lfsr_q[23] ^ lfsr_q[24] ^ lfsr_q[26] ^ lfsr_q[27] ^ lfsr_q[29] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[9] ^ data_trans[11] ^ data_trans[12] ^ data_trans[14] ^ data_trans[16] ^ data_trans[18] ^ data_trans[19] ^ data_trans[23] ^ data_trans[24] ^ data_trans[26] ^ data_trans[27] ^ data_trans[29] ^ data_trans[31];
    lfsr_c[23] = lfsr_q[0] ^ lfsr_q[1] ^ lfsr_q[6] ^ lfsr_q[9] ^ lfsr_q[13] ^ lfsr_q[15] ^ lfsr_q[16] ^ lfsr_q[17] ^ lfsr_q[19] ^ lfsr_q[20] ^ lfsr_q[26] ^ lfsr_q[27] ^ lfsr_q[29] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[1] ^ data_trans[6] ^ data_trans[9] ^ data_trans[13] ^ data_trans[15] ^ data_trans[16] ^ data_trans[17] ^ data_trans[19] ^ data_trans[20] ^ data_trans[26] ^ data_trans[27] ^ data_trans[29] ^ data_trans[31];
    lfsr_c[24] = lfsr_q[1] ^ lfsr_q[2] ^ lfsr_q[7] ^ lfsr_q[10] ^ lfsr_q[14] ^ lfsr_q[16] ^ lfsr_q[17] ^ lfsr_q[18] ^ lfsr_q[20] ^ lfsr_q[21] ^ lfsr_q[27] ^ lfsr_q[28] ^ lfsr_q[30] ^ data_trans[1] ^ data_trans[2] ^ data_trans[7] ^ data_trans[10] ^ data_trans[14] ^ data_trans[16] ^ data_trans[17] ^ data_trans[18] ^ data_trans[20] ^ data_trans[21] ^ data_trans[27] ^ data_trans[28] ^ data_trans[30];
    lfsr_c[25] = lfsr_q[2] ^ lfsr_q[3] ^ lfsr_q[8] ^ lfsr_q[11] ^ lfsr_q[15] ^ lfsr_q[17] ^ lfsr_q[18] ^ lfsr_q[19] ^ lfsr_q[21] ^ lfsr_q[22] ^ lfsr_q[28] ^ lfsr_q[29] ^ lfsr_q[31] ^ data_trans[2] ^ data_trans[3] ^ data_trans[8] ^ data_trans[11] ^ data_trans[15] ^ data_trans[17] ^ data_trans[18] ^ data_trans[19] ^ data_trans[21] ^ data_trans[22] ^ data_trans[28] ^ data_trans[29] ^ data_trans[31];
    lfsr_c[26] = lfsr_q[0] ^ lfsr_q[3] ^ lfsr_q[4] ^ lfsr_q[6] ^ lfsr_q[10] ^ lfsr_q[18] ^ lfsr_q[19] ^ lfsr_q[20] ^ lfsr_q[22] ^ lfsr_q[23] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[26] ^ lfsr_q[28] ^ lfsr_q[31] ^ data_trans[0] ^ data_trans[3] ^ data_trans[4] ^ data_trans[6] ^ data_trans[10] ^ data_trans[18] ^ data_trans[19] ^ data_trans[20] ^ data_trans[22] ^ data_trans[23] ^ data_trans[24] ^ data_trans[25] ^ data_trans[26] ^ data_trans[28] ^ data_trans[31];
    lfsr_c[27] = lfsr_q[1] ^ lfsr_q[4] ^ lfsr_q[5] ^ lfsr_q[7] ^ lfsr_q[11] ^ lfsr_q[19] ^ lfsr_q[20] ^ lfsr_q[21] ^ lfsr_q[23] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[26] ^ lfsr_q[27] ^ lfsr_q[29] ^ data_trans[1] ^ data_trans[4] ^ data_trans[5] ^ data_trans[7] ^ data_trans[11] ^ data_trans[19] ^ data_trans[20] ^ data_trans[21] ^ data_trans[23] ^ data_trans[24] ^ data_trans[25] ^ data_trans[26] ^ data_trans[27] ^ data_trans[29];
    lfsr_c[28] = lfsr_q[2] ^ lfsr_q[5] ^ lfsr_q[6] ^ lfsr_q[8] ^ lfsr_q[12] ^ lfsr_q[20] ^ lfsr_q[21] ^ lfsr_q[22] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[26] ^ lfsr_q[27] ^ lfsr_q[28] ^ lfsr_q[30] ^ data_trans[2] ^ data_trans[5] ^ data_trans[6] ^ data_trans[8] ^ data_trans[12] ^ data_trans[20] ^ data_trans[21] ^ data_trans[22] ^ data_trans[24] ^ data_trans[25] ^ data_trans[26] ^ data_trans[27] ^ data_trans[28] ^ data_trans[30];
    lfsr_c[29] = lfsr_q[3] ^ lfsr_q[6] ^ lfsr_q[7] ^ lfsr_q[9] ^ lfsr_q[13] ^ lfsr_q[21] ^ lfsr_q[22] ^ lfsr_q[23] ^ lfsr_q[25] ^ lfsr_q[26] ^ lfsr_q[27] ^ lfsr_q[28] ^ lfsr_q[29] ^ lfsr_q[31] ^ data_trans[3] ^ data_trans[6] ^ data_trans[7] ^ data_trans[9] ^ data_trans[13] ^ data_trans[21] ^ data_trans[22] ^ data_trans[23] ^ data_trans[25] ^ data_trans[26] ^ data_trans[27] ^ data_trans[28] ^ data_trans[29] ^ data_trans[31];
    lfsr_c[30] = lfsr_q[4] ^ lfsr_q[7] ^ lfsr_q[8] ^ lfsr_q[10] ^ lfsr_q[14] ^ lfsr_q[22] ^ lfsr_q[23] ^ lfsr_q[24] ^ lfsr_q[26] ^ lfsr_q[27] ^ lfsr_q[28] ^ lfsr_q[29] ^ lfsr_q[30] ^ data_trans[4] ^ data_trans[7] ^ data_trans[8] ^ data_trans[10] ^ data_trans[14] ^ data_trans[22] ^ data_trans[23] ^ data_trans[24] ^ data_trans[26] ^ data_trans[27] ^ data_trans[28] ^ data_trans[29] ^ data_trans[30];
    lfsr_c[31] = lfsr_q[5] ^ lfsr_q[8] ^ lfsr_q[9] ^ lfsr_q[11] ^ lfsr_q[15] ^ lfsr_q[23] ^ lfsr_q[24] ^ lfsr_q[25] ^ lfsr_q[27] ^ lfsr_q[28] ^ lfsr_q[29] ^ lfsr_q[30] ^ lfsr_q[31] ^ data_trans[5] ^ data_trans[8] ^ data_trans[9] ^ data_trans[11] ^ data_trans[15] ^ data_trans[23] ^ data_trans[24] ^ data_trans[25] ^ data_trans[27] ^ data_trans[28] ^ data_trans[29] ^ data_trans[30] ^ data_trans[31];

    nextcrc32 = lfsr_c;
  end
endfunction

always @(*)
begin
  for (i=0; i<8;i=i+1)
  begin
    crc_data[i+24] = ~crc_accum[31-i];
    crc_data[i+16] = ~crc_accum[23-i];
    crc_data[i+8]  = ~crc_accum[15-i];
    crc_data[i]    = ~crc_accum[7-i];
  end
end


function [31:0] ancillaryheader;
  input [WORD_CW-1:0] index;
  begin
    case(index)
      0       : ancillaryheader = ANC_WORD0;   // rows, columns, frame/field
      1       : ancillaryheader = ANC_WORD1;   // colour format
      2       : ancillaryheader = 32'b0;       // prior image CRC, 0 while P=0
      3       : ancillaryheader = 32'b0;       // misc control word, unused
      default : ancillaryheader = 32'b0;
    endcase
  end
endfunction


function [31:0] containerheader;
  input [CON_CW-1:0] index;
  begin
    case(index)
      0  : containerheader = containercount;
      1  : containerheader = 32'h0;                                           // Clip ID, unused
      2  : containerheader = 32'h0;                                           // Time stamp, unused
      3  : containerheader = 32'h0;
      4  : containerheader = {FRAME_RATE_CODE, TX_RATE_CODE, 16'h0};
      5  : containerheader = {CONTAINER_MODE, NUM_OBJECTS, 8'h00, EXT_HDR_SIZE};
      6  : containerheader = {OBJ_CLASS_ANC, LINK_POINTER, SPDV_INDEX};
      7  : containerheader = OBJ0_SIZE;
      8  : containerheader = OBJ0_OFFSET;
      9  : containerheader = 32'b0;                                           //  standard
      10 : containerheader = {OBJ_CLASS_AUD, LINK_POINTER, SPDV_INDEX};
      11 : containerheader = OBJ1_SIZE;
      12 : containerheader = OBJ1_OFFSET;
      13 : containerheader = 32'b0;
      14 : containerheader = {OBJ_CLASS_VID, LINK_POINTER, SPDV_INDEX};
      15 : containerheader = OBJ2_SIZE;
      16 : containerheader = OBJ2_OFFSET;
      17 : containerheader = 32'b0;
      18 : containerheader = {OBJ_CLASS_VID, LINK_POINTER, SPDV_INDEX};
      19 : containerheader = OBJ3_SIZE;
      20 : containerheader = OBJ3_OFFSET;
      21 : containerheader = 32'b0;
      default: containerheader = 32'b0;
    endcase
  end
endfunction


function [31:0] frameheader;
  input [HDR_CW-1:0] index;
  begin
    case(index)
      0 : frameheader = {R_CTL, cur_dest_id};                    // MULTISTREAM: per-stream D_ID
      1 : frameheader = {8'h00, cur_src_id};                     // MULTISTREAM: per-stream S_ID, CS_CTL = 0
      2 : if (lineindex == (VACTIVE - 1) && frame_in_line == (FRAMESPERLINE - 1))
            frameheader = {FC_TYPE, F_CTL_END};
          else
            frameheader = {FC_TYPE, F_CTL_MID};
      3 : frameheader = {containercount[7:0], 8'b0, seq_count};  // SEQ_ID, DF_CTL, SEQ_CNT
      4 : frameheader = {16'hFFFF, 16'hFFFF};                    // OX_ID, RX_ID
      5 : frameheader = 32'b0;
      default : frameheader = 32'b0;
    endcase
  end
endfunction



always @(posedge clk or negedge rst_n) begin
  if (!rst_n)
    state <= IDLE;
  else
    state <= nextstate;
end


always @(*)
begin
  nextstate = state;
  case(state)

    IDLE:
    begin
      if (idle_counter < idle_target)
        nextstate = IDLE;
      else if (!txfifo_rempty)
        nextstate = SENDSOF;
      else
        nextstate = IDLE;
    end

    SENDSOF:
    begin
      nextstate = SENDHDR;
    end

    SENDHDR:
    begin
      if (frame_hdrcnt == (HEADERWORDS - 1) && object0 == 1'b0)
        nextstate = SENDCONT;
      else if (frame_hdrcnt == (HEADERWORDS - 1))
        nextstate = SENDPAYLOAD;
      else
        nextstate = SENDHDR;
    end

    SENDCONT:
    begin
      if (container_hdrcnt == (CONTAINERWORDS - 1))
        nextstate = SENDANC;
      else
        nextstate = SENDCONT;
    end

    SENDANC:
    begin
      if (wordcounter == (ANCILLARYWORDS - 1))
        nextstate = SENDCRC;
      else
        nextstate = SENDANC;
    end

    SENDPAYLOAD:
    begin
      if (wordcounter == (PAYLOADWORDS - 1))
        nextstate = SENDCRC;
      else
        nextstate = SENDPAYLOAD;
    end

    SENDCRC:
    begin
      nextstate = SENDEOF;
    end

    SENDEOF:
    begin
      nextstate = IDLE;
    end

    default:
      nextstate = IDLE;
  endcase
end


always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin
    xcvr_txdata      <= 32'h00000000;
    xcvr_txcharisk   <= 4'b0001;
    wordcounter      <= {WORD_CW{1'b0}};
    containercount   <= 0;
    idle_counter     <= {IDLE_CW{1'b0}};
    idle_target      <= {IDLE_CW{1'b0}};
    lineindex        <= {LINE_CW{1'b0}};
    frame_in_line    <= {FIL_CW{1'b0}};
    object0          <= 1'b0;
    lastframe        <= 1'b0;
    txfifo_rden      <= 1'b0;
    seq_count        <= 16'h0;
    frame_hdrcnt     <= {HDR_CW{1'b0}};
    container_hdrcnt <= {CON_CW{1'b0}};
    crc_accum        <= 32'hFFFFFFFF;
    stream           <= 3'd0;           // MULTISTREAM
    seq_line_base    <= 16'h0;          // MULTISTREAM
  end
  else begin
    case(state)

      IDLE :
      begin
        xcvr_txdata    <= IDLEWORD;
        xcvr_txcharisk <= 4'b1000;
        crc_accum      <= 32'hFFFFFFFF;
        txfifo_rden    <= 1'b0;

        if (idle_counter < idle_target)
          idle_counter <= idle_counter + 1'b1;
      end

      SENDSOF:
      begin
        xcvr_txcharisk <= 4'b1000;
        if (object0 == 1'b0) begin
          seq_count   <= 0;              // SEQ_CNT = 0 on the Object 0 frame
          xcvr_txdata <= SOFIWORD;
        end
        else begin
          seq_count   <= seq_count + 1;
          xcvr_txdata <= SOFNWORD;
        end
      end

      SENDHDR:
      begin
        xcvr_txdata    <= frameheader(frame_hdrcnt);
        xcvr_txcharisk <= 4'b0000;
        crc_accum      <= nextcrc32(crc_accum, frameheader(frame_hdrcnt));
        if (frame_hdrcnt == (HEADERWORDS - 1)) begin
          frame_hdrcnt <= {HDR_CW{1'b0}};
          if (object0 == 1'b1)
            txfifo_rden <= 1'b1;
        end
        else begin
          frame_hdrcnt <= frame_hdrcnt + 1'b1;
          txfifo_rden  <= 1'b0;
        end
      end

      SENDCONT:
      begin
        xcvr_txdata    <= containerheader(container_hdrcnt);
        xcvr_txcharisk <= 4'b0000;
        crc_accum      <= nextcrc32(crc_accum, containerheader(container_hdrcnt));
        if (container_hdrcnt == (CONTAINERWORDS - 1))
          container_hdrcnt <= {CON_CW{1'b0}};
        else
          container_hdrcnt <= container_hdrcnt + 1'b1;
      end

      SENDANC:
      begin
        xcvr_txdata    <= ancillaryheader(wordcounter);
        xcvr_txcharisk <= 4'b0000;
        crc_accum      <= nextcrc32(crc_accum, ancillaryheader(wordcounter));
        if (wordcounter == (ANCILLARYWORDS - 1))
          wordcounter <= {WORD_CW{1'b0}};
        else
          wordcounter <= wordcounter + 1'b1;
      end

      SENDPAYLOAD:
      begin
        xcvr_txdata    <= txfifo_rdata;
        xcvr_txcharisk <= 4'b0000;
        crc_accum      <= nextcrc32(crc_accum, txfifo_rdata);
        if (wordcounter == (PAYLOADWORDS - 1))
        begin
          txfifo_rden <= 1'b0;
          wordcounter <= {WORD_CW{1'b0}};
        end
        else begin
          txfifo_rden <= 1'b1;
          wordcounter <= wordcounter + 1'b1;
        end
      end

      SENDCRC:
      begin
        xcvr_txdata    <= crc_data;
        xcvr_txcharisk <= 4'b0000;
      end

      SENDEOF:
      begin
        xcvr_txcharisk <= 4'b1000;
        idle_counter   <= {{(IDLE_CW-1){1'b0}}, 1'b1};

        if (object0 == 1'b0) begin
          // MULTISTREAM: every stream sends its own Object 0 frame, back to back.
          // Only after the LAST stream's Object 0 do we move on to video lines.
          lineindex      <= lineindex;
          frame_in_line  <= {FIL_CW{1'b0}};
          containercount <= containercount;
          lastframe      <= lastframe;
          seq_line_base  <= 16'h0;
          if (stream == (NUM_STREAMS - 1)) begin
            stream         <= 3'd0;
            object0        <= 1'b1;
            idle_target    <= POST_OBJ0_IDLE;
          end
          else begin
            stream         <= stream + 1'b1;
            object0        <= 1'b0;                 // next stream's Object 0
            idle_target    <= INTER_OBJ2_IDLE;
          end
          if (next_rd == 1'b0)
            xcvr_txdata <= EOFN_NEG_RD;
          else
            xcvr_txdata <= EOFN_POS_RD;
        end
        else if (frame_in_line == (FRAMESPERLINE - 1)) begin

          frame_in_line <= {FIL_CW{1'b0}};
          if (stream != (NUM_STREAMS - 1)) begin
            // MULTISTREAM: this stream finished its line slot. The next stream
            // now sends the SAME line. Each stream gets an equal slot
            // (its frames + END_LINE_IDLE), so stream k is offset by k/NUM_STREAMS
            // of a line time  -> "line synchronous" multistream.
            stream         <= stream + 1'b1;
            idle_target    <= END_LINE_IDLE;
            seq_count      <= seq_line_base;        // next stream's SEQ_CNT restarts from the same base
            lineindex      <= lineindex;
            containercount <= containercount;
            object0        <= object0;
            lastframe      <= lastframe;
            if (lineindex == (VACTIVE - 1)) begin   // last frame of this stream's sequence
              if (next_rd == 1'b0)
                xcvr_txdata <= EOFT_NEG_RD;
              else
                xcvr_txdata <= EOFT_POS_RD;
            end
            else begin
              if (next_rd == 1'b0)
                xcvr_txdata <= EOFN_NEG_RD;
              else
                xcvr_txdata <= EOFN_POS_RD;
            end
          end
          else if (lineindex == (VACTIVE - 1)) begin
            stream         <= 3'd0;                 // MULTISTREAM
            idle_target    <= PRE_OBJ0_IDLE;
            lineindex      <= {LINE_CW{1'b0}};
            containercount <= containercount + 1;
            object0        <= 1'b0;
            lastframe      <= 1'b1;
            if (next_rd == 1'b0)
              xcvr_txdata <= EOFT_NEG_RD;
            else
              xcvr_txdata <= EOFT_POS_RD;
          end
          else begin
            stream         <= 3'd0;                 // MULTISTREAM
            seq_line_base  <= seq_count;            // MULTISTREAM: base for the next line slot
            idle_target    <= END_LINE_IDLE;
            lineindex      <= lineindex + 1'b1;
            containercount <= containercount;
            object0        <= object0;
            lastframe      <= lastframe;
            if (next_rd == 1'b0)
              xcvr_txdata <= EOFN_NEG_RD;
            else
              xcvr_txdata <= EOFN_POS_RD;
          end
        end
        else begin

          frame_in_line  <= frame_in_line + 1'b1;
          idle_target    <= INTER_OBJ2_IDLE;
          lineindex      <= lineindex;
          containercount <= containercount;
          lastframe      <= lastframe;
          object0        <= object0;
          if (next_rd == 1'b0)
            xcvr_txdata <= EOFN_NEG_RD;
          else
            xcvr_txdata <= EOFN_POS_RD;
        end
      end

      default:
      begin
        xcvr_txdata    <= IDLEWORD;
        xcvr_txcharisk <= 4'b1000;
      end
    endcase
  end
end


assign advb_txdata    = {xcvr_txdata[7:0], xcvr_txdata[15:8],
                         xcvr_txdata[23:16], xcvr_txdata[31:24]};
assign advb_txcharisk = {xcvr_txcharisk[0], xcvr_txcharisk[1],
                         xcvr_txcharisk[2], xcvr_txcharisk[3]};

endmodule
