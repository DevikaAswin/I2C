// =============================================================================
// stream_select  (NEW - multistream receive side)
// -----------------------------------------------------------------------------
// Sits between `sync` and an UNCHANGED `advbrx`.
//
// ARINC 818 multistream: several video streams share one link; each stream's
// FC frames carry a unique D_ID (header word 0) and/or S_ID (header word 1).
//
// This block lets through ONLY the frames whose D_ID == MATCH_DID and
// S_ID == MATCH_SID. Frames of the other streams are replaced word-for-word
// by IDLE ordered sets. So the advbrx behind it sees a normal single-stream
// link: its own frames separated by idles. advbrx needs no change.
//
// How a frame is found:  SOF = a K word followed directly by a data word.
//                        EOF = the next K word after that.
// The header is checked with a 3-word delay line:
//        d2 = SOF   d1 = header word 0 (R_CTL, D_ID)   d0 = header word 1 (CS_CTL, S_ID)
//
// Byte order: works for both bus orders. If the K character of the SOF sits
// in byte 0 (charisk 4'b0001) the header bytes are swapped before comparing.
// Idles used for blanking are a copy of the last real idle seen on the bus,
// so they are always in the bus's own byte order.
//
// Latency: 4 clocks.
// =============================================================================
module stream_select #(
  parameter [23:0] MATCH_DID = 24'h007912,
  parameter [23:0] MATCH_SID = 24'h000001
)(
  input             clk,
  input             rst_n,
  input      [31:0] in_data,
  input      [3:0]  in_charisk,
  output reg [31:0] out_data,
  output reg [3:0]  out_charisk
);

reg [31:0] d0, d1, d2;
reg [3:0]  k0, k1, k2;
reg        in_frame;
reg        pass;
reg [31:0] idle_word;
reg [3:0]  idle_k;

function [31:0] bswap;
  input [31:0] w;
  begin
    bswap = {w[7:0], w[15:8], w[23:16], w[31:24]};
  end
endfunction

wire        sof_at_d2 = (k2 != 4'b0000) && (k1 == 4'b0000) && (k0 == 4'b0000);
wire        lsb_first = (k2 == 4'b0001);
wire [31:0] hdr0      = lsb_first ? bswap(d1) : d1;   // {R_CTL , D_ID}
wire [31:0] hdr1      = lsb_first ? bswap(d0) : d0;   // {CS_CTL, S_ID}
wire        id_match  = (hdr0[23:0] == MATCH_DID) && (hdr1[23:0] == MATCH_SID);
wire        eof_at_d2 = in_frame && (k2 != 4'b0000) && !sof_at_d2;

// keep the word at d2?  SOF: decide now.  Inside a frame: follow the decision.
// Outside frames (idles, other primitives): always pass.
wire        keep      = sof_at_d2 ? id_match : (in_frame ? pass : 1'b1);

always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin
    d0 <= 32'h0;  d1 <= 32'h0;  d2 <= 32'h0;
    k0 <= 4'h0;   k1 <= 4'h0;   k2 <= 4'h0;
    in_frame    <= 1'b0;
    pass        <= 1'b0;
    idle_word   <= 32'hBC95B5B5;     // replaced by the first real idle seen
    idle_k      <= 4'b1000;
    out_data    <= 32'h0;
    out_charisk <= 4'h0;
  end
  else begin
    // 3-word delay line
    d0 <= in_data;  d1 <= d0;  d2 <= d1;
    k0 <= in_charisk; k1 <= k0; k2 <= k1;

    // frame tracking
    if (sof_at_d2) begin
      in_frame <= 1'b1;
      pass     <= id_match;
    end
    else if (eof_at_d2) begin
      in_frame <= 1'b0;
      pass     <= 1'b0;
    end

    // learn the idle word (K word outside any frame, not an SOF)
    if (!in_frame && !sof_at_d2 && (k2 != 4'b0000)) begin
      idle_word <= d2;
      idle_k    <= k2;
    end

    // output
    if (keep) begin
      out_data    <= d2;
      out_charisk <= k2;
    end
    else begin
      out_data    <= idle_word;
      out_charisk <= idle_k;
    end
  end
end

endmodule
