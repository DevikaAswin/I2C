module arinc818_core
#(
  // MULTISTREAM (new): number of video streams on the one link. 1 = original design.
  parameter NUM_STREAMS = 1
)
(
  input  wire        clk,
  input  wire        tx_userclk2,
  input  wire        rx_userclk2,
  input  wire        rst_n,
  output wire        txfifo_wfull,
  input  wire [31:0] txfifo_wdata,
  input  wire        txfifo_wren,
  output wire [31:0] advb_txdata,
  output wire [3:0]  advb_txcharisk,
  input  wire [31:0] advb_rxdata,
  input  wire [3:0]  advb_rxcharisk,
  output wire        rxfifo_rempty,
  input  wire        rxfifo_rden,
  output wire [31:0] rxfifo_rdata,
  input  wire        reset_tx_done,
  input  wire        reset_rx_done

);

// =============================================================================
// MULTISTREAM SETTINGS (new) - the only things to edit
// -----------------------------------------------------------------------------
// Stream IDs. Stream k uses bits [24*k +: 24]. Stream 0 = your original IDs
// (D_ID 007912, S_ID 000001). Every stream must differ in S_ID or D_ID.
// The SAME table is used by the transmitter (to stamp the frames) and by the
// receiver (to pick the frames out of the incoming link).
localparam [191:0] STREAM_SRC_ID  = {24'h000008, 24'h000007, 24'h000006, 24'h000005,
                                     24'h000004, 24'h000003, 24'h000002, 24'h000001};
localparam [191:0] STREAM_DEST_ID = {8{24'h007912}};
//
// RX_FANOUT = 1 : the INCOMING link is a normal single-stream source.
//                 It is received once (exactly like before) and the same video
//                 is written into every stream FIFO -> the TX sends NUM_STREAMS
//                 copies, each with its own S_ID/D_ID. Use this to test
//                 multistream TX with your existing single source.
// RX_FANOUT = 0 : the INCOMING link already carries NUM_STREAMS streams.
//                 Each stream is picked out by its IDs (stream_select) and
//                 received by its own advbrx into its own FIFO.
localparam RX_FANOUT = 1;
// =============================================================================

localparam RX_DEMUX = (NUM_STREAMS > 1) && (RX_FANOUT == 0);

wire        txfifo_rden;
wire [31:0] txfifo_rdata;
wire        txfifo_rempty;
wire        rxfifo_wfull;
wire [31:0] rxfifo_wdata;
wire        rxfifo_wren;
wire [31:0] aligned_advb_rxdata;
wire [3:0]  aligned_advb_rxcharisk;
wire [3:0]  aligned_advb_rxcharisk_sync;
wire [31:0] aligned_advb_rxdata_sync ;
wire [31:0] advb_rxdata_sync;
wire [3:0] advb_rxcharisk_sync;
wire        crcerror;
wire[31:0] advb_rxdata1;

// MULTISTREAM (new): all-stream buses between the FIFOs and advbtx
wire [NUM_STREAMS-1:0]    txfifo_rden_all;
wire [NUM_STREAMS-1:0]    txfifo_rempty_all;
wire [32*NUM_STREAMS-1:0] txfifo_rdata_all;
// MULTISTREAM (new): what stream 0's advbrx sees (filtered or direct)
wire [31:0] rx0_data;
wire [3:0]  rx0_charisk;

//asyncfifo #(
//  .DATASIZE(32),
//  .ADDRSIZE(9)
//) tx_fifo
//(
//  .wclk  (clk),
//  .wrstn (reset_tx_done),
//  .winc  (txfifo_wren),
//  .wdata (txfifo_wdata),
//  .rclk  (tx_userclk2),
//  .rrstn (reset_tx_done),
//  .rinc  (txfifo_rden),
//  .rdata (txfifo_rdata),
//  .wfull (txfifo_wfull),
//  .rempty(txfifo_rempty)
//);

// ---------------- STREAM 0 : your original FIFO, unchanged ----------------
asyncfifo #(
  .DATASIZE(32),
  .ADDRSIZE(11)
) tx_fifo
(
  .wclk  (rx_userclk2),
  .wrstn (reset_rx_done),
  .winc  (rxfifo_wren),
  .wdata (rxfifo_wdata),
  .rclk  (tx_userclk2),
  .rrstn ( reset_tx_done),
  .rinc  (txfifo_rden),
  .rdata (txfifo_rdata),
  .wfull (txfifo_wfull),
  .rempty(txfifo_rempty)
);

assign txfifo_rden            = txfifo_rden_all[0];
assign txfifo_rempty_all[0]   = txfifo_rempty;
assign txfifo_rdata_all[31:0] = txfifo_rdata;

advbtx #(
  .HACTIVE          (1280),
  .VACTIVE          (1024),
  .BytesPerPixel    (3),
  .FRAMERATE        (60),
  .NUM_STREAMS      (NUM_STREAMS),       // MULTISTREAM
  .STREAM_SRC_ID    (STREAM_SRC_ID),     // MULTISTREAM
  .STREAM_DEST_ID   (STREAM_DEST_ID)     // MULTISTREAM

) transmit
(
  .clk               (tx_userclk2),
  .rst_n             ( reset_tx_done),
  .advb_txdata       (advb_txdata),
  .advb_txcharisk    (advb_txcharisk),
  .txfifo_rempty_all (txfifo_rempty_all),
  .txfifo_rden_all   (txfifo_rden_all),
  .txfifo_rdata_all  (txfifo_rdata_all)
);




rxdata_formater align
(
  .clk                    (rx_userclk2),
  .rst_n                  ( reset_rx_done ),
  .advb_rxdata            (advb_rxdata),
  .advb_rxcharisk         (advb_rxcharisk),
  .aligned_advb_rxdata    (aligned_advb_rxdata),
  .aligned_advb_rxcharisk (aligned_advb_rxcharisk)
);

// MULTISTREAM: in demux mode stream 0 only gets its own frames;
// otherwise (single stream / fanout) advbrx sees sync's output directly, as before.
generate
  if (RX_DEMUX) begin : g_sel0
    stream_select #(
      .MATCH_DID (STREAM_DEST_ID[23:0]),
      .MATCH_SID (STREAM_SRC_ID [23:0])
    ) sel
    (
      .clk         (rx_userclk2),
      .rst_n       (reset_rx_done),
      .in_data     (advb_rxdata_sync),
      .in_charisk  (advb_rxcharisk_sync),
      .out_data    (rx0_data),
      .out_charisk (rx0_charisk)
    );
  end
  else begin : g_nosel0
    assign rx0_data    = advb_rxdata_sync;
    assign rx0_charisk = advb_rxcharisk_sync;
  end
endgenerate

advbrx #(
  .HACTIVE          (1280),
  .VACTIVE          (1024),
  .BytesPerPixel    (3),
  .FRAMERATE        (60)

) receive
(
  .clk           (rx_userclk2),
  .rst_n         ( reset_rx_done ),

.advb_data(rx0_data),                    // MULTISTREAM: was advb_rxdata_sync
    .advb_rxdata   (advb_rxdata1),

    .advb_rxcharisk(rx0_charisk),        // MULTISTREAM: was advb_rxcharisk_sync
  .rxfifo_wfull  (rxfifo_wfull),
  .rxfifo_wdata  (rxfifo_wdata),
  .rxfifo_wren   (rxfifo_wren),
  .crcerror      (crcerror)
);

sync synctop(
.clk             (rx_userclk2),
.rxrst           ( reset_rx_done ),
.rxcharisk       (aligned_advb_rxcharisk),
.advb_rxdata     (aligned_advb_rxdata),
.rxcharisk_sync  (advb_rxcharisk_sync),
.advb_rxdata_sync(advb_rxdata_sync)
);

// ---------------- STREAMS 1 .. NUM_STREAMS-1 (MULTISTREAM, new) ----------------
genvar s;
generate
  for (s = 1; s < NUM_STREAMS; s = s + 1) begin : g_stream

    wire [31:0] fifo_wdata;     // what goes into this stream's FIFO
    wire        fifo_wren;
    wire        fifo_wfull;

    if (RX_DEMUX) begin : g_rx
      // pick this stream's frames out of the link, receive them with an
      // unchanged copy of advbrx
      wire [31:0] rx_data;
      wire [3:0]  rx_charisk;
      wire        rxfifo_wfull_s;     // left unconnected, same as stream 0
      wire [31:0] rxfifo_wdata_s;
      wire        rxfifo_wren_s;
      wire        crcerror_s;
      wire [31:0] advb_rxdata1_s;

      stream_select #(
        .MATCH_DID (STREAM_DEST_ID[24*s +: 24]),
        .MATCH_SID (STREAM_SRC_ID [24*s +: 24])
      ) sel
      (
        .clk         (rx_userclk2),
        .rst_n       (reset_rx_done),
        .in_data     (advb_rxdata_sync),
        .in_charisk  (advb_rxcharisk_sync),
        .out_data    (rx_data),
        .out_charisk (rx_charisk)
      );

      advbrx #(
        .HACTIVE          (1280),
        .VACTIVE          (1024),
        .BytesPerPixel    (3),
        .FRAMERATE        (60)
      ) receive
      (
        .clk           (rx_userclk2),
        .rst_n         ( reset_rx_done ),
        .advb_data     (rx_data),
        .advb_rxdata   (advb_rxdata1_s),
        .advb_rxcharisk(rx_charisk),
        .rxfifo_wfull  (rxfifo_wfull_s),
        .rxfifo_wdata  (rxfifo_wdata_s),
        .rxfifo_wren   (rxfifo_wren_s),
        .crcerror      (crcerror_s)
      );

      assign fifo_wdata = rxfifo_wdata_s;
      assign fifo_wren  = rxfifo_wren_s;
    end
    else begin : g_fanout
      // single-stream input: same received video goes into every stream FIFO
      assign fifo_wdata = rxfifo_wdata;
      assign fifo_wren  = rxfifo_wren;
    end

    asyncfifo #(
      .DATASIZE(32),
      .ADDRSIZE(11)
    ) tx_fifo
    (
      .wclk  (rx_userclk2),
      .wrstn (reset_rx_done),
      .winc  (fifo_wren),
      .wdata (fifo_wdata),
      .rclk  (tx_userclk2),
      .rrstn ( reset_tx_done),
      .rinc  (txfifo_rden_all[s]),
      .rdata (txfifo_rdata_all[32*s +: 32]),
      .wfull (fifo_wfull),
      .rempty(txfifo_rempty_all[s])
    );

  end
endgenerate

//asyncfifo #(
//  .DATASIZE(32),
//  .ADDRSIZE(11)
//) rx_fifo
//(
//  .wclk  (rx_userclk2),
//  .wrstn ( reset_rx_done ),
//  .winc  (rxfifo_wren),
//  .wdata (rxfifo_wdata),
//  .rclk  (clk),
//  .rrstn (reset_rx_done),
//  .rinc  (rxfifo_rden),
//  .rdata (rxfifo_rdata),
//  .wfull (rxfifo_wfull),
//  .rempty(rxfifo_rempty)
//);


endmodule
